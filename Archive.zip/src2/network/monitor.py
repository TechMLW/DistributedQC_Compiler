from typing import Dict, Tuple, Optional, List, Any
import random
from network.link import Link


class NetworkMonitor:
    """
    Observer and dynamic telemetry interface over the authoritative Topology.
    Ensures that all monitored link states, demands, utilizations, and environmental metrics
    are synchronized with the underlying Link objects and Topology graph.
    """

    def __init__(self, topology: Optional[Any] = None):
        if topology is not None:
            self.topology = topology
        else:
            # Create internal fallback Topology
            from network.topology import Topology
            self.topology = Topology()

    def attach_topology(self, topology: Any) -> None:
        """Attach an authoritative Topology instance to the monitor."""
        self.topology = topology

    @property
    def links(self) -> Dict[Tuple[int, int], dict]:
        """
        Return current link state dictionary dynamically extracted from the authoritative Topology.
        Guarantees that NetworkMonitor and Topology/Link never desynchronize.
        """
        return {
            (link.source, link.destination): link.to_dict()
            for link in self.topology.links
        }

    def register_link(
        self,
        source: int,
        destination: int,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        congestion: Optional[float] = None,
        capacity: float = 10.0,
        demand: float = 0.0
    ) -> Link:
        """Register or update a link in the authoritative topology."""
        existing = self.topology.get_link(source, destination)
        if existing is not None:
            self.topology.update_link(
                source=source,
                destination=destination,
                latency=latency,
                fidelity=fidelity,
                bell_pairs=bell_pairs,
                capacity=capacity,
                demand=demand,
                congestion=congestion
            )
            return existing
        else:
            # Ensure QPUs exist in topology
            if source not in self.topology.qpus:
                self.topology.add_qpu(source, capacity=4)
            if destination not in self.topology.qpus:
                self.topology.add_qpu(destination, capacity=4)

            return self.topology.connect(
                a=source,
                b=destination,
                latency=latency,
                fidelity=fidelity,
                bell_pairs=bell_pairs,
                capacity=capacity,
                demand=demand,
                congestion=congestion
            )

    def get_state(self, source: int, destination: int) -> Optional[dict]:
        """Get the current authoritative state of a link in either direction."""
        link = self.topology.get_link(source, destination)
        if link is not None:
            return link.to_dict()
        return None

    def update_demand(
        self,
        source: int,
        destination: int,
        demand: float,
        queue_len: int = 0
    ) -> None:
        """Update link demand and recompute utilization and congestion on authoritative link."""
        self.topology.update_link(source, destination, demand=demand)

    def consume_bell_pair(self, source: int, destination: int, count: int = 1) -> bool:
        """Consume Bell pairs for an active communication link."""
        link = self.topology.get_link(source, destination)
        if link is not None:
            return link.consume_bell_pair(count)
        return False

    def recalculate_from_routes(self, routes: List[List[int]]) -> None:
        """
        Recalculate demand, utilization, and congestion across all links
        based on active routed multi-hop paths.
        """
        self.topology.recalculate_demand_from_routes(routes)

    def reset_resources(self) -> None:
        """Reset Bell pairs and demands back to initial configuration."""
        self.topology.reset_resources()

    def apply_environmental_change(
        self,
        source: int,
        destination: int,
        latency: Optional[float] = None,
        fidelity: Optional[float] = None,
        bell_pairs: Optional[int] = None,
        capacity: Optional[float] = None,
        demand: Optional[float] = None,
        congestion: Optional[float] = None
    ) -> None:
        """Apply an environmental network perturbation directly to the authoritative Link."""
        self.topology.update_link(
            source=source,
            destination=destination,
            latency=latency,
            fidelity=fidelity,
            bell_pairs=bell_pairs,
            capacity=capacity,
            demand=demand,
            congestion=congestion
        )

    def update(
        self,
        rng: Optional[random.Random] = None,
        routes: Optional[List[List[int]]] = None,
        latency_step: tuple[int, int] = (-2, 3),
        fidelity_step: tuple[float, float] = (-0.003, 0.002),
        bell_pair_step: tuple[int, int] = (-2, 2),
        capacity_step: tuple[int, int] = (-1, 1),
    ) -> None:
        """
        Simulate one generic environmental time step.

        Only environmental link properties are perturbed here. Congestion is
        NEVER randomized; it is recomputed from the supplied routed workload.
        A caller can provide a seeded ``random.Random`` for reproducibility.
        """
        rng = rng or random.Random()

        for link in self.topology.links:
            new_lat = max(1.0, link.latency + rng.randint(*latency_step))
            new_fid = max(0.80, min(1.0, link.fidelity + rng.uniform(*fidelity_step)))
            new_bell = max(0, min(link.initial_bell_pairs, link.bell_pairs + rng.randint(*bell_pair_step)))
            min_capacity = max(1.0, 0.5 * link.initial_capacity)
            max_capacity = max(min_capacity, 1.5 * link.initial_capacity)
            new_capacity = max(
                min_capacity,
                min(max_capacity, link.capacity + rng.randint(*capacity_step))
            )

            self.topology.update_link(
                source=link.source,
                destination=link.destination,
                latency=new_lat,
                fidelity=new_fid,
                bell_pairs=new_bell,
                capacity=new_capacity
            )

        if routes is not None:
            self.recalculate_from_routes(routes)

    def print_state(self) -> None:
        """Print formatted current network state."""
        print("\n===== Network State =====")
        for link in self.topology.links:
            print(
                f"({link.source}, {link.destination}) | "
                f"Latency={link.latency:.1f} ms | "
                f"Fidelity={link.fidelity:.3f} | "
                f"BellPairs={link.bell_pairs}/{link.initial_bell_pairs} | "
                f"Demand={link.demand:.1f}/{link.capacity:.1f} | "
                f"Utilization={link.utilization:.2f} | "
                f"Congestion={link.congestion:.1f}%"
            )