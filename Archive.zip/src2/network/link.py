from typing import Optional


class Link:
    """
    Represents an inter-QPU communication link with Bell-pair resources and congestion metrics.

    Attributes:
        source: Source QPU ID.
        destination: Destination QPU ID.
        latency: Base latency in ms.
        fidelity: Quantum channel entanglement fidelity (0.0 to 1.0).
        bell_pairs: Current available Bell pairs (EPR pairs).
        capacity: Maximum communication capacity (operations/bandwidth per time window).
        demand: Current communication demand on this link.
        queue: Number of queued operations waiting for this link.
    """

    def __init__(
        self,
        source: int,
        destination: int,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0,
        demand: float = 0.0,
        congestion: Optional[float] = None
    ):
        self.source = source
        self.destination = destination
        self.latency = float(latency)
        self.fidelity = float(fidelity)
        self.initial_bell_pairs = int(bell_pairs)
        self.bell_pairs = int(bell_pairs)
        self.consumed_bell_pairs = 0
        self.initial_capacity = max(1.0, float(capacity))
        self.capacity = self.initial_capacity
        self.demand = float(demand)
        self.queue = 0

        # Congestion percentage (0 to 100%)
        if congestion is not None:
            self._congestion = float(congestion)
        else:
            self._congestion = self._compute_congestion()

    @property
    def utilization(self) -> float:
        """Utilization ratio rho = D_e / C_e."""
        return self.demand / self.capacity

    @property
    def congestion(self) -> float:
        """Congestion percentage based on demand/capacity or manual override."""
        return self._congestion

    @congestion.setter
    def congestion(self, value: float) -> None:
        self._congestion = max(0.0, min(100.0, float(value)))

    def _compute_congestion(self) -> float:
        """Demand-derived congestion model rho = D_e / C_e in percentage."""
        rho = self.demand / self.capacity
        return min(100.0, rho * 100.0)

    def update_demand(self, demand: float, queue_len: int = 0) -> None:
        """Update link demand and recompute congestion from demand/capacity."""
        self.demand = max(0.0, float(demand))
        self.queue = max(0, int(queue_len))
        self._congestion = self._compute_congestion()

    def refresh_congestion(self) -> None:
        """Recompute congestion from the authoritative demand/capacity state."""
        self._congestion = self._compute_congestion()

    def consume_bell_pair(self, count: int = 1) -> bool:
        """
        Consume Bell pairs for remote operation communication.
        Returns True if successful, False if insufficient resources.
        """
        if self.bell_pairs >= count:
            self.bell_pairs -= count
            self.consumed_bell_pairs += count
            return True
        return False

    def replenish_bell_pairs(self, count: int) -> None:
        """Replenish Bell pairs on the link (e.g. from continuous generation)."""
        self.bell_pairs += count

    def reset_resources(self) -> None:
        """Reset Bell-pair accounting and demand back to initial state."""
        self.bell_pairs = self.initial_bell_pairs
        self.consumed_bell_pairs = 0
        self.demand = 0.0
        self.queue = 0
        self._congestion = 0.0

    def cost(
        self,
        alpha: float = 1.0,
        beta: float = 1.0,
        gamma: float = 1.0,
        delta: float = 1.0,
        epsilon: float = 1.0
    ) -> float:
        """
        Calculate composite edge communication cost.
        cost = alpha * latency + beta * congestion + gamma * (1 - fidelity) * 100 + delta * (20 / (bell_pairs + 1)) + epsilon
        """
        fid_penalty = (1.0 - self.fidelity) * 100.0
        bell_penalty = 20.0 / (self.bell_pairs + 1)
        return (
            alpha * self.latency
            + beta * self.congestion
            + gamma * fid_penalty
            + delta * bell_penalty
            + epsilon
        )

    def to_dict(self) -> dict:
        """Return dict representation of link state."""
        return {
            "source": self.source,
            "destination": self.destination,
            "latency": self.latency,
            "fidelity": self.fidelity,
            "bell_pairs": self.bell_pairs,
            "initial_bell_pairs": self.initial_bell_pairs,
            "consumed_bell_pairs": self.consumed_bell_pairs,
            "capacity": self.capacity,
            "initial_capacity": self.initial_capacity,
            "demand": self.demand,
            "utilization": self.utilization,
            "queue": self.queue,
            "congestion": self.congestion
        }

    def __str__(self) -> str:
        return (
            f"{self.source} <--> {self.destination} | "
            f"Latency={self.latency:.1f}ms | "
            f"Fidelity={self.fidelity:.3f} | "
            f"BellPairs={self.bell_pairs}/{self.initial_bell_pairs} | "
            f"Congestion={self.congestion:.1f}% (Demand={self.demand}/{self.capacity})"
        )