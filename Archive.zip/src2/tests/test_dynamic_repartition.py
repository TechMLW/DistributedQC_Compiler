import os
import shutil
import unittest
from qiskit import QuantumCircuit
import networkx as nx

from network.topology import Topology
from network.monitor import NetworkMonitor
from compiler.compiler import DQCCompiler
from compiler.communication_graph import CommunicationGraph
from compiler.repartition_trigger import RepartitionTrigger
from compiler.optimizer import Optimizer
from compiler.communication_cost import CommunicationCost


class TestDynamicRepartitionFix(unittest.TestCase):

    def setUp(self):
        self.test_graph_dir = "test_graph_output"
        os.makedirs(self.test_graph_dir, exist_ok=True)

    def tearDown(self):
        if os.path.exists(self.test_graph_dir):
            shutil.rmtree(self.test_graph_dir)

    def test_demand_derived_congestion_from_actual_routes(self):
        """
        Verify that route demand is counted strictly from active remote operations
        and congestion = (demand / capacity) * 100 on every traversed link.
        """
        # 3 QPUs in line: 0 <--> 1 <--> 2
        topo = Topology.create_line_topology(num_qpus=3, qpu_capacity=3, capacity=2.0)

        # Create circuit: 3 cross-QPU interactions between QPU 0 and QPU 2
        # Logical qubits 0, 1 on QPU 0; 4, 5 on QPU 2; 2, 3 on QPU 1
        qc = QuantumCircuit(6)
        qc.cx(0, 4)  # Multi-hop route [0, 1, 2] -> demand on (0, 1) and (1, 2)
        qc.cx(1, 5)  # Multi-hop route [0, 1, 2] -> demand on (0, 1) and (1, 2)
        qc.cx(0, 2)  # Route [0, 1] -> demand on (0, 1)

        partitions = {0: [0, 1], 1: [2, 3], 2: [4, 5]}
        compiler = DQCCompiler()
        compiled = compiler.recompile_for_partition(qc, partitions, topo)

        link_01 = topo.get_link(0, 1)
        link_12 = topo.get_link(1, 2)

        # Link (0, 1) traversed 3 times: demand = 3.0, capacity = 2.0 -> utilization = 1.5, congestion = 100%
        self.assertEqual(link_01.demand, 3.0)
        self.assertEqual(link_01.utilization, 1.5)
        self.assertEqual(link_01.congestion, 100.0)

        # Link (1, 2) traversed 2 times: demand = 2.0, capacity = 2.0 -> utilization = 1.0, congestion = 100%
        self.assertEqual(link_12.demand, 2.0)
        self.assertEqual(link_12.utilization, 1.0)
        self.assertEqual(link_12.congestion, 100.0)

    def test_trigger_without_repartition_no_image_created(self):
        """
        Verify that when a trigger fires but no beneficial partition change is found,
        no actual_repartition image is created.
        """
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=10.0)
        monitor = NetworkMonitor(topology=topo)

        # Symmetrical GHZ state: optimal partition is already [0, 1] on QPU0, [2, 3] on QPU1
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)

        comm_graph = CommunicationGraph(output_dir=self.test_graph_dir).build(qc)
        current_partition = {0: [0, 1], 1: [2, 3]}

        # Trigger condition: high latency threshold crossed on link (0, 1)
        topo.update_link(0, 1, latency=35.0)  # > limit 20.0
        trigger = RepartitionTrigger(latency_limit=20.0)

        triggered, reason = trigger.check(topo)
        self.assertTrue(triggered)
        self.assertIn("latency", reason)

        # Run optimizer
        optimizer = Optimizer(monitor=monitor)
        result = optimizer.adaptive_optimize(
            comm_graph,
            current_partition,
            threshold=5.0,
            topology=topo
        )

        # Partition should NOT change because candidate swap doesn't reduce total cut
        self.assertFalse(result.changed)
        self.assertEqual(len(result.changed_qubits), 0)

        # Verify no repartition image was generated in test_graph_dir
        generated_images = [f for f in os.listdir(self.test_graph_dir) if f.startswith("actual_repartition")]
        self.assertEqual(len(generated_images), 0)

    def test_beneficial_repartition_and_resynchronization(self):
        """
        Verify that when a beneficial repartition is accepted:
        1. changed is True with exact changed qubits.
        2. Exactly one actual_repartition image is created.
        3. Compiler recomputes routes, demand, congestion, and current cost on authoritative topology.
        """
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=5.0)
        monitor = NetworkMonitor(topology=topo)
        cg_builder = CommunicationGraph(output_dir=self.test_graph_dir)

        # Circuit: Heavy interaction between qubits (0, 2) and (1, 3)
        qc = QuantumCircuit(4)
        for _ in range(5):
            qc.cx(0, 2)  # 5 gates between 0 and 2
            qc.cx(1, 3)  # 5 gates between 1 and 3

        comm_graph = cg_builder.build(qc)

        # Poor initial partition: 0 on QPU 0, 2 on QPU 1 (causing 10 remote gates)
        initial_partition = {0: [0, 1], 1: [2, 3]}
        compiler = DQCCompiler()
        compiled = compiler.recompile_for_partition(qc, initial_partition, topo)

        initial_cost = CommunicationCost(monitor).calculate(comm_graph, initial_partition, topology=topo)
        self.assertGreater(initial_cost, 50.0)

        # Trigger repartitioning due to high congestion
        topo.update_link(0, 1, latency=25.0)
        trigger = RepartitionTrigger(latency_limit=20.0)
        triggered, reason = trigger.check(topo)
        self.assertTrue(triggered)

        optimizer = Optimizer(monitor=monitor)
        result = optimizer.adaptive_optimize(
            comm_graph,
            initial_partition,
            threshold=5.0,
            topology=topo
        )

        self.assertTrue(result.changed)
        self.assertGreater(len(result.changed_qubits), 0)

        # Save single actual repartition image
        img_file = cg_builder.draw(
            comm_graph,
            filename="actual_repartition_01_step_01.png",
            title="Actual Repartition #1",
            partitions=result.partition,
            subtitle=f"Trigger: {reason}"
        )
        self.assertTrue(os.path.exists(img_file))

        # Recompile and verify synchronized state on topology
        recompiled = compiler.recompile_for_partition(qc, result.partition, topo)
        self.assertEqual(len(recompiled.remote_operations), 0)  # Zero remote ops with optimal partition [0, 2] and [1, 3]

        new_cost = CommunicationCost(monitor).calculate(comm_graph, result.partition, topology=topo)
        self.assertEqual(new_cost, 0.0)
        self.assertEqual(topo.get_link(0, 1).demand, 0.0)
        self.assertEqual(topo.get_link(0, 1).congestion, 0.0)


if __name__ == "__main__":
    unittest.main()

