import unittest
from network.link import Link
from network.monitor import NetworkMonitor


class TestCongestionModel(unittest.TestCase):

    def test_link_demand_and_utilization(self):
        # Capacity = 10, Demand = 5 -> rho = 0.5, Congestion = 50%
        link = Link(source=0, destination=1, capacity=10.0, demand=5.0)
        self.assertEqual(link.utilization, 0.5)
        self.assertEqual(link.congestion, 50.0)

        # Update demand to 12 -> utilization = 1.2, Congestion capped at 100%
        link.update_demand(12.0)
        self.assertEqual(link.utilization, 1.2)
        self.assertEqual(link.congestion, 100.0)

    def test_monitor_route_recalculation(self):
        monitor = NetworkMonitor()
        monitor.register_link(0, 1, capacity=5.0)
        monitor.register_link(1, 2, capacity=10.0)

        # 3 routes traversing [0, 1, 2]
        routes = [[0, 1, 2], [0, 1, 2], [0, 1, 2]]
        monitor.recalculate_from_routes(routes)

        state_01 = monitor.get_state(0, 1)
        state_12 = monitor.get_state(1, 2)

        self.assertEqual(state_01["demand"], 3.0)
        self.assertEqual(state_01["utilization"], 3.0 / 5.0)
        self.assertEqual(state_01["congestion"], 60.0)

        self.assertEqual(state_12["demand"], 3.0)
        self.assertEqual(state_12["utilization"], 3.0 / 10.0)
        self.assertEqual(state_12["congestion"], 30.0)

    def test_bell_pair_consumption(self):
        link = Link(source=0, destination=1, bell_pairs=10)
        success = link.consume_bell_pair(3)
        self.assertTrue(success)
        self.assertEqual(link.bell_pairs, 7)
        self.assertEqual(link.consumed_bell_pairs, 3)

        # Fail when consuming more than remaining
        fail = link.consume_bell_pair(8)
        self.assertFalse(fail)
        self.assertEqual(link.bell_pairs, 7)


if __name__ == "__main__":
    unittest.main()

