import argparse
import csv
import os
import random
from pathlib import Path

from qiskit import QuantumCircuit

from network.topology import Topology
from network.monitor import NetworkMonitor
from compiler.communication_graph import CommunicationGraph
from compiler.kl_partitioner import KLPartitioner
from compiler.router import ShortestPathRouter
from compiler.communication_cost import CommunicationCost
from compiler.compiler import DQCCompiler
from compiler.optimizer import Optimizer
from compiler.repartition_trigger import RepartitionTrigger


def build_workload_circuit(num_qubits: int = 6, repeats: int = 4) -> QuantumCircuit:
    """Build a repeatable interaction-heavy workload; no dynamic network events are encoded here."""
    if num_qubits < 4:
        raise ValueError("The workload requires at least 4 qubits.")

    qc = QuantumCircuit(num_qubits, name="Adaptive_DQC_Workload")
    for q in range(num_qubits):
        qc.h(q)

    # Pairwise interaction clusters distributed across the logical circuit.
    pairs = []
    for q in range(0, num_qubits - 1, 2):
        pairs.append((q, q + 1))
    if num_qubits >= 4:
        for q in range(0, num_qubits - 2, 2):
            pairs.append((q, q + 2))

    for _ in range(max(1, repeats)):
        for a, b in pairs:
            qc.cx(a, b)

    # A sparse inter-cluster backbone keeps the workload genuinely distributed.
    for q in range(0, num_qubits - 1, 2):
        if q + 1 < num_qubits and q + 2 < num_qubits:
            qc.cx(q + 1, q + 2)

    return qc


def flatten_partition(logical_to_qpu, num_qpus):
    return {
        qpu: sorted(q for q, assigned in logical_to_qpu.items() if assigned == qpu)
        for qpu in range(num_qpus)
    }


def partition_signature(partition):
    return tuple(
        (qpu, tuple(sorted(qubits)))
        for qpu, qubits in sorted(partition.items())
    )


def reset_graph_outputs(graph_dir: Path) -> None:
    graph_dir.mkdir(parents=True, exist_ok=True)
    for path in graph_dir.iterdir():
        if path.suffix.lower() == ".png":
            path.unlink()
    for csv_name in ("simulation_results.csv", "repartition_events.csv"):
        path = graph_dir / csv_name
        if path.exists():
            path.unlink()


def main() -> None:
    parser = argparse.ArgumentParser(description="Adaptive DQC dynamic repartition simulation")
    parser.add_argument("--steps", type=int, default=50, help="Number of adaptive simulation steps")
    parser.add_argument("--bell-pairs", type=int, default=50, help="Initial Bell pairs per inter-QPU link")
    parser.add_argument("--qpus", type=int, default=3, help="Number of QPUs")
    parser.add_argument("--qpu-capacity", type=int, default=2, help="Physical/logical qubit capacity per QPU")
    parser.add_argument("--qubits", type=int, default=6, help="Number of logical qubits")
    parser.add_argument("--link-capacity", type=float, default=8.0, help="Initial operations-per-window capacity per link")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for environmental dynamics")
    parser.add_argument("--output-dir", default="graph", help="Output directory")
    args = parser.parse_args()

    if args.steps <= 0:
        raise ValueError("steps must be positive")
    if args.qpus <= 0 or args.qpu_capacity <= 0 or args.qubits <= 0:
        raise ValueError("qpus, qpu-capacity and qubits must be positive")
    if args.qpus * args.qpu_capacity < args.qubits:
        raise ValueError("Total QPU capacity must be at least the number of logical qubits")

    graph_dir = Path(args.output_dir)
    reset_graph_outputs(graph_dir)
    rng = random.Random(args.seed)

    print("=" * 72)
    print("ADAPTIVE DQC COMPILER — DYNAMIC REPARTITION SIMULATION")
    print("=" * 72)
    print(f"Steps: {args.steps} | QPUs: {args.qpus} | Qubits: {args.qubits} | Bell pairs/link: {args.bell_pairs} | Seed: {args.seed}")

    qc = build_workload_circuit(args.qubits)
    cg_builder = CommunicationGraph(output_dir=str(graph_dir))
    comm_graph = cg_builder.build(qc)

    topology = Topology.create_line_topology(
        num_qpus=args.qpus,
        qpu_capacity=args.qpu_capacity,
        latency=15.0,
        fidelity=0.98,
        bell_pairs=args.bell_pairs,
        capacity=args.link_capacity,
    )
    monitor = NetworkMonitor(topology=topology)

    compiler = DQCCompiler(
        partitioner=KLPartitioner(),
        router=ShortestPathRouter(alpha=1.0, beta=1.0, gamma=1.0, delta=1.0, epsilon=1.0),
        protocol="telegate",
    )

    # Initial partition is produced by the compiler, not scripted by the simulation.
    compiled = compiler.compile(
        circuit=qc,
        topology=topology,
        consume_resources=False,
    )
    current_partition = flatten_partition(compiled.logical_to_qpu, args.qpus)

    cg_builder.draw(
        comm_graph,
        filename="initial_partition.png",
        title="Initial DQC Partition",
        partitions=current_partition,
        subtitle=f"Remote operations: {len(compiled.remote_operations)} | Max congestion: {max((l.congestion for l in topology.links), default=0.0):.1f}%",
    )

    trigger = RepartitionTrigger(
        latency_limit=32.0,
        fidelity_limit=0.93,
        congestion_limit=75.0,
        bellpair_limit=max(5, args.bell_pairs // 5),
    )
    optimizer = Optimizer(monitor=monitor)
    cost_calc = CommunicationCost(monitor=monitor, router=compiler.router)

    counters = {
        "repartition_checks": 0,
        "repartition_triggers": 0,
        "optimizer_runs": 0,
        "actual_repartitions": 0,
        "trigger_events_without_partition_change": 0,
    }

    results = []
    repartition_events = []

    for step in range(1, args.steps + 1):
        counters["repartition_checks"] += 1

        # Generic environmental evolution. No individual link/time outcome is prescribed.
        current_routes = list(compiled.routes.values())
        monitor.update(rng=rng, routes=current_routes)

        # Re-evaluate the current partition against the new environment.
        compiled = compiler.recompile_for_partition(
            circuit=qc,
            partitions=current_partition,
            topology=topology,
            interaction_graph=comm_graph,
            consume_resources=False,
            route_stabilization_rounds=3,
        )

        current_cost = cost_calc.calculate_from_remote_operations(
            compiled.remote_operations,
            topology=topology,
        )

        max_congestion = max((link.congestion for link in topology.links), default=0.0)
        avg_congestion = (
            sum(link.congestion for link in topology.links) / len(topology.links)
            if topology.links else 0.0
        )
        min_bell_pairs = min((link.bell_pairs for link in topology.links), default=args.bell_pairs)

        triggered, reason = trigger.check(topology)
        candidate_partition = current_partition
        changed = False
        changed_qubits = []
        new_cost = current_cost
        action = "NO REPARTITION"

        if triggered:
            counters["repartition_triggers"] += 1
            counters["optimizer_runs"] += 1

            opt_res = optimizer.adaptive_optimize(
                graph=comm_graph,
                current_partition=current_partition,
                threshold=0.01,
                topology=topology,
                capacities={q: args.qpu_capacity for q in range(args.qpus)},
            )

            candidate_partition = opt_res.partition
            changed = opt_res.changed
            changed_qubits = list(opt_res.changed_qubits)
            new_cost = opt_res.new_cost if changed else current_cost

            if changed and partition_signature(candidate_partition) != partition_signature(current_partition):
                counters["actual_repartitions"] += 1
                action = "ACTUAL REPARTITION"
                old_partition = current_partition
                current_partition = candidate_partition

                compiled = compiler.recompile_for_partition(
                    circuit=qc,
                    partitions=current_partition,
                    topology=topology,
                    interaction_graph=comm_graph,
                    consume_resources=False,
                    route_stabilization_rounds=3,
                )
                new_cost = cost_calc.calculate_from_remote_operations(
                    compiled.remote_operations,
                    topology=topology,
                )

                image_name = (
                    f"actual_repartition_{counters['actual_repartitions']:02d}_step_{step:02d}.png"
                )
                cg_builder.draw(
                    comm_graph,
                    filename=image_name,
                    title=f"Actual Repartition #{counters['actual_repartitions']:02d} — Step {step:02d}",
                    partitions=current_partition,
                    subtitle=(
                        f"Trigger: {reason} | Changed qubits: {changed_qubits} | "
                        f"Remote ops: {len(compiled.remote_operations)} | "
                        f"Max congestion: {max((l.congestion for l in topology.links), default=0.0):.1f}%"
                    ),
                )
                repartition_events.append({
                    "event": counters["actual_repartitions"],
                    "step": step,
                    "reason": reason,
                    "changed_qubits": changed_qubits,
                    "old_cost": opt_res.old_cost,
                    "new_cost": new_cost,
                    "old_partition": partition_signature(old_partition),
                    "new_partition": partition_signature(current_partition),
                    "image": image_name,
                })
            else:
                counters["trigger_events_without_partition_change"] += 1
        
        print(
            f"Step {step:02d} | trigger={'YES' if triggered else 'NO':3} | "
            f"action={action:19} | remote_ops={len(compiled.remote_operations):3d} | "
            f"max_cong={max_congestion:6.1f}% | min_EPR={min_bell_pairs:2d} | "
            f"cost={new_cost:9.2f}"
        )

        results.append({
            "step": step,
            "triggered": int(triggered),
            "trigger_reason": reason,
            "action": action,
            "actual_repartition": int(action == "ACTUAL REPARTITION"),
            "changed_qubits": ";".join(map(str, changed_qubits)),
            "remote_ops": len(compiled.remote_operations),
            "max_congestion_pct": round(max((l.congestion for l in topology.links), default=0.0), 4),
            "avg_congestion_pct": round(avg_congestion, 4),
            "min_bell_pairs": min_bell_pairs,
            "communication_cost": round(new_cost, 6),
            "partition": repr(current_partition),
        })

    cg_builder.draw(
        comm_graph,
        filename="final_partition.png",
        title="Final DQC Partition",
        partitions=current_partition,
        subtitle=(
            f"{args.steps} adaptive steps | Actual repartitions: "
            f"{counters['actual_repartitions']}"
        ),
    )

    with (graph_dir / "simulation_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)

    if repartition_events:
        with (graph_dir / "repartition_events.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(repartition_events[0].keys()))
            writer.writeheader()
            writer.writerows(repartition_events)

    print("\n" + "=" * 72)
    print("FINAL ADAPTIVE SIMULATION SUMMARY")
    print("=" * 72)
    for key, value in counters.items():
        print(f"{key:42}: {value}")
    print(f"Results CSV{'':32}: {graph_dir / 'simulation_results.csv'}")
    print(f"Initial Bell pairs/link{'':19}: {args.bell_pairs}")
    print(f"Final partition{'':26}: {current_partition}")


if __name__ == "__main__":
    main()
