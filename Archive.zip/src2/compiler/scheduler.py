from typing import List, Dict, Tuple, Optional, Any, Union
from network.topology import Topology
from compiler.remote_ops import RemoteOperation, LocalOperation


class SchedulingError(Exception):
    """Raised when remote operations cannot be scheduled due to resource constraints."""
    pass


class RemoteOperationScheduler:
    """
    Dependency-aware deterministic scheduler for local and remote operations across a multi-QPU network.
    
    Enforces:
        1. Qubit dependencies (a qubit cannot participate in multiple operations simultaneously).
        2. Network link capacity / mutual exclusion (concurrent operations cannot collide on the same link).
        3. Bell-pair / EPR resource accounting per link.
    """

    def __init__(
        self,
        allow_resource_delay: bool = True,
        max_time_steps: int = 10000
    ):
        self.allow_resource_delay = allow_resource_delay
        self.max_time_steps = max_time_steps

    def schedule(
        self,
        operations: List[Union[LocalOperation, RemoteOperation]],
        topology: Topology,
        consume_resources: bool = True
    ) -> Tuple[List[Union[LocalOperation, RemoteOperation]], int, Dict[str, Any]]:
        """
        Schedule a sequence of local and remote operations deterministically.
        
        Returns:
            - scheduled_operations: List of operations with assigned scheduled_time.
            - makespan: Total execution time steps (duration of entire distributed computation).
            - resource_stats: Dict of Bell-pair consumption and link utilization metrics.
        """
        qubit_free_time: Dict[int, int] = {}       # logical_qubit -> available time step
        link_reservations: Dict[Tuple[int, int], Dict[int, int]] = {}  # (u, v) -> {time_step: count}

        # Initialize link tracking
        for link in topology.links:
            u, v = link.source, link.destination
            link_reservations[(min(u, v), max(u, v))] = {}

        scheduled_ops: List[Union[LocalOperation, RemoteOperation]] = []

        for op in operations:
            if isinstance(op, LocalOperation):
                # Earliest time all participating qubits are available
                start_t = 0
                for q in op.logical_qubits:
                    start_t = max(start_t, qubit_free_time.get(q, 0))

                duration = 1
                op.scheduled_time = start_t
                op.duration = duration
                end_t = start_t + duration

                for q in op.logical_qubits:
                    qubit_free_time[q] = end_t

                # Local operations don't consume inter-QPU links
                scheduled_ops.append(op)

            elif isinstance(op, RemoteOperation):
                if not op.path or len(op.path) < 2:
                    raise ValueError(f"Remote operation {op} has no valid multi-hop path.")

                # Required Bell pairs per traversed link
                bell_pairs_needed = op.protocol.bell_pairs_per_hop()

                # Check if Bell pairs are available on all links along path
                path_links = []
                for i in range(len(op.path) - 1):
                    u, v = op.path[i], op.path[i + 1]
                    link_obj = topology.get_link(u, v)
                    if link_obj is None:
                        raise SchedulingError(f"No physical link between QPU {u} and QPU {v} along path {op.path}.")
                    if link_obj.bell_pairs < bell_pairs_needed:
                        raise SchedulingError(
                            f"Bell-pair resource exhaustion on link ({u}, {v}): "
                            f"Available={link_obj.bell_pairs}, Required={bell_pairs_needed} for {op}."
                        )
                    path_links.append(link_obj)

                # Earliest time both qubits are free
                q_earliest = max(
                    qubit_free_time.get(op.logical_control, 0),
                    qubit_free_time.get(op.logical_target, 0)
                )

                duration = max(1, int(round((len(op.path) - 1) * op.protocol.latency_multiplier())))
                op.duration = duration

                # Find earliest time step t >= q_earliest where all path links have capacity
                chosen_t = q_earliest
                found = False

                while chosen_t < self.max_time_steps:
                    conflict = False
                    for t in range(chosen_t, chosen_t + duration):
                        for link_obj in path_links:
                            link_key = (min(link_obj.source, link_obj.destination), max(link_obj.source, link_obj.destination))
                            current_load = link_reservations[link_key].get(t, 0)
                            if current_load >= link_obj.capacity:
                                conflict = True
                                break
                        if conflict:
                            break

                    if not conflict:
                        found = True
                        break
                    chosen_t += 1

                if not found:
                    raise SchedulingError(f"Could not schedule remote operation {op} within {self.max_time_steps} time steps.")

                # Reserve links across duration
                for t in range(chosen_t, chosen_t + duration):
                    for link_obj in path_links:
                        link_key = (min(link_obj.source, link_obj.destination), max(link_obj.source, link_obj.destination))
                        link_reservations[link_key][t] = link_reservations[link_key].get(t, 0) + 1

                # Consume Bell pairs only when this schedule represents execution.
                # Simulation/optimization previews can set consume_resources=False.
                if consume_resources:
                    for link_obj in path_links:
                        link_obj.consume_bell_pair(bell_pairs_needed)

                op.scheduled_time = chosen_t
                op.compute_resource_requirements()

                # Update qubit busy times
                end_t = chosen_t + duration
                qubit_free_time[op.logical_control] = end_t
                qubit_free_time[op.logical_target] = end_t

                scheduled_ops.append(op)

        makespan = max(qubit_free_time.values()) if qubit_free_time else 0

        initial_epr, consumed_epr, remaining_epr = topology.get_total_bell_pairs()
        resource_stats = {
            "makespan": makespan,
            "total_initial_bell_pairs": initial_epr,
            "total_consumed_bell_pairs": consumed_epr,
            "total_remaining_bell_pairs": remaining_epr,
            "link_stats": {
                f"({l.source}, {l.destination})": l.to_dict()
                for l in topology.links
            }
        }

        return scheduled_ops, makespan, resource_stats
