from typing import Dict, List, Union


class ObjectiveFunction:
    """
    Partition objective used by the adaptive repartitioner.

    Network conditions already enter ``communication_cost`` through the
    path-aware router, so this objective deliberately adds only a partition-
    dependent load-balance term. Global sums of link health would be identical
    for every candidate partition and therefore cannot guide the optimizer.
    """

    def __init__(
        self,
        monitor=None,
        alpha: float = 1.0,
        beta: float = 1.0,
        gamma: float = 1.0,
        delta: float = 1.0,
        epsilon: float = 1.0,
        zeta: float = 1.0
    ):
        self.monitor = monitor
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.gamma = float(gamma)
        self.delta = float(delta)
        self.epsilon = float(epsilon)
        self.zeta = float(zeta)

    def evaluate(
        self,
        communication_cost: float,
        partitions: Union[Dict[int, List[int]], Dict[int, int]]
    ) -> float:
        qpu_to_qubits: Dict[int, List[int]] = {}
        for k, v in partitions.items():
            if isinstance(v, (list, tuple, set)):
                qpu_to_qubits[int(k)] = list(v)
            else:
                qpu_to_qubits.setdefault(int(v), []).append(int(k))

        sizes = [len(v) for v in qpu_to_qubits.values()]
        imbalance = (max(sizes) - min(sizes)) if sizes else 0.0

        return self.alpha * float(communication_cost) + self.beta * float(imbalance)
