from typing import Dict, List, Tuple, Optional, Any, Union
from qiskit import QuantumCircuit

from network.topology import Topology
from compiler.analyzer import CircuitAnalyzer
from compiler.communication_graph import CommunicationGraph
from compiler.kl_partitioner import KLPartitioner
from compiler.partitioner import Partitioner
from compiler.mapper import PhysicalMapper
from compiler.router import BaseRouter, ShortestPathRouter
from compiler.communication_cost import CommunicationCost
from compiler.remote_ops import LocalOperation, RemoteOperation
from compiler.scheduler import RemoteOperationScheduler
from compiler.compiled_dqc import CompiledDQC


class DQCCompiler:
    """
    End-to-end Distributed Quantum Computing (DQC) Compiler.
    
    Compiles a monolithic Qiskit QuantumCircuit into a distributed execution plan
    across a multi-QPU network with physical mapping, multi-hop routing,
    dynamic demand-derived congestion, Bell-pair accounting, and per-QPU local circuits.
    """

    def __init__(
        self,
        partitioner: Optional[Any] = None,
        router: Optional[BaseRouter] = None,
        protocol: str = "telegate",
        alpha: float = 1.0,
        beta: float = 1.0,
        gamma: float = 1.0,
        delta: float = 1.0,
        epsilon: float = 1.0
    ):
        self.analyzer = CircuitAnalyzer()
        self.comm_graph_builder = CommunicationGraph()
        self.partitioner = partitioner if partitioner is not None else KLPartitioner()
        self.mapper = PhysicalMapper()
        self.router = router if router is not None else ShortestPathRouter(
            alpha=alpha, beta=beta, gamma=gamma, delta=delta, epsilon=epsilon
        )
        self.cost_calculator = CommunicationCost(
            router=self.router,
            alpha=alpha, beta=beta, gamma=gamma, delta=delta, epsilon=epsilon
        )
        self.scheduler = RemoteOperationScheduler()
        self.protocol = protocol

    def compile(
        self,
        circuit: QuantumCircuit,
        topology: Optional[Topology] = None,
        num_qpus: Optional[int] = None,
        qpu_capacity: Optional[int] = None,
        consume_resources: bool = True
    ) -> CompiledDQC:
        """
        Execute full compilation pipeline on input quantum circuit.
        """
        num_qubits = circuit.num_qubits

        # 1. Configure default topology if none provided
        if topology is None:
            n_qpus = num_qpus if num_qpus is not None else 2
            cap = qpu_capacity if qpu_capacity is not None else max(4, (num_qubits + n_qpus - 1) // n_qpus)
            topology = Topology.create_line_topology(num_qpus=n_qpus, qpu_capacity=cap)

        num_qpus = len(topology.qpus)
        capacities = {qpu_id: qpu.capacity for qpu_id, qpu in topology.qpus.items()}

        # Reset any prior resource allocations on the topology
        topology.reset_resources()

        # 2. Build Interaction / Communication Graph
        interaction_graph = self.comm_graph_builder.build(circuit, include_all_nodes=True)

        # 3. Partitioning
        if hasattr(self.partitioner, "partition"):
            try:
                partitions = self.partitioner.partition(
                    interaction_graph,
                    num_qpus=num_qpus,
                    capacities=capacities
                )
            except TypeError:
                partitions = self.partitioner.partition(interaction_graph)
        else:
            partitions = KLPartitioner().partition(interaction_graph, num_qpus=num_qpus, capacities=capacities)

        # 4. Finish compilation with given partition
        return self.recompile_for_partition(
            circuit=circuit,
            partitions=partitions,
            topology=topology,
            interaction_graph=interaction_graph,
            consume_resources=consume_resources
        )

    def recompile_for_partition(
        self,
        circuit: QuantumCircuit,
        partitions: Dict[int, List[int]],
        topology: Topology,
        interaction_graph: Optional[Any] = None,
        consume_resources: bool = True,
        route_stabilization_rounds: int = 3
    ) -> CompiledDQC:
        """
        Recompile the circuit given a specific or updated partition assignment.
        Used both for initial compilation and after an actual repartition.
        """
        if interaction_graph is None:
            interaction_graph = self.comm_graph_builder.build(circuit, include_all_nodes=True)

        analysis = self.analyzer.analyze(circuit)

        # Physical QPU Mapping
        logical_to_qpu, logical_to_physical = self.mapper.map_qubits(
            partitions=partitions,
            topology=topology,
            interaction_graph=interaction_graph
        )

        # Local / Remote Operation Extraction
        local_operations: List[LocalOperation] = []
        remote_operations: List[RemoteOperation] = []
        all_operations: List[Union[LocalOperation, RemoteOperation]] = []

        for idx, gate_info in enumerate(analysis["gate_sequence"]):
            gate_name = gate_info["name"]
            q_indices = gate_info["qubits"]
            c_indices = gate_info["clbits"]
            params = gate_info["params"]

            if len(q_indices) == 1:
                # 1-qubit gate: purely local
                q = q_indices[0]
                qpu_id = logical_to_qpu[q]
                local_op = LocalOperation(
                    gate=gate_name,
                    logical_qubits=[q],
                    qpu=qpu_id,
                    operation_index=idx,
                    params=params,
                    clbits=c_indices
                )
                local_operations.append(local_op)
                all_operations.append(local_op)

            elif len(q_indices) == 2:
                # 2-qubit gate
                q0, q1 = q_indices[0], q_indices[1]
                qpu0 = logical_to_qpu[q0]
                qpu1 = logical_to_qpu[q1]

                if qpu0 == qpu1:
                    # Intra-QPU local 2-qubit gate
                    local_op = LocalOperation(
                        gate=gate_name,
                        logical_qubits=[q0, q1],
                        qpu=qpu0,
                        operation_index=idx,
                        params=params,
                        clbits=c_indices
                    )
                    local_operations.append(local_op)
                    all_operations.append(local_op)
                else:
                    # Inter-QPU remote 2-qubit gate
                    remote_op = RemoteOperation(
                        gate=gate_name,
                        logical_control=q0,
                        logical_target=q1,
                        source_qpu=qpu0,
                        destination_qpu=qpu1,
                        operation_index=idx,
                        params=params,
                        protocol_name=self.protocol
                    )
                    remote_operations.append(remote_op)
                    all_operations.append(remote_op)

            else:
                # Multi-qubit gate (>2 qubits) - assign to QPU of first qubit
                qpu_id = logical_to_qpu[q_indices[0]]
                local_op = LocalOperation(
                    gate=gate_name,
                    logical_qubits=q_indices,
                    qpu=qpu_id,
                    operation_index=idx,
                    params=params,
                    clbits=c_indices
                )
                local_operations.append(local_op)
                all_operations.append(local_op)

        # Network routing with short fixed-point stabilization:
        # route -> demand-derived congestion -> reroute. This keeps routing adaptive
        # without prescribing individual network events in the simulation.
        routes: Dict[int, List[int]] = {}
        previous_routes: Optional[Dict[int, List[int]]] = None
        rounds = max(1, int(route_stabilization_rounds))

        for _ in range(rounds):
            candidate_routes: Dict[int, List[int]] = {}
            for remote_op in remote_operations:
                path = self.router.route(
                    topology, remote_op.source_qpu, remote_op.destination_qpu
                )
                candidate_routes[remote_op.operation_index] = path

            if candidate_routes == previous_routes:
                routes = candidate_routes
                break

            routes = candidate_routes
            topology.recalculate_demand_from_routes(list(routes.values()))
            previous_routes = candidate_routes

        for remote_op in remote_operations:
            path = routes.get(remote_op.operation_index)
            if not path:
                raise RuntimeError(
                    f"No route produced for remote operation {remote_op.operation_index}."
                )
            remote_op.path = path
            remote_op.cost = self.router.calculate_path_cost(topology, path)
            remote_op.compute_resource_requirements()

        # Ensure demand/congestion exactly matches the final selected routes.
        topology.recalculate_demand_from_routes(list(routes.values()))

        # Deterministic Scheduling & EPR Accounting
        scheduled_ops, makespan, resource_stats = self.scheduler.schedule(
            operations=all_operations,
            topology=topology,
            consume_resources=consume_resources
        )

        # Local Circuit Generation per QPU
        qpu_circuits: Dict[int, QuantumCircuit] = {}
        for qpu_id, qpu in topology.qpus.items():
            local_qc = QuantumCircuit(qpu.capacity, name=f"QPU_{qpu_id}_Circuit")
            qpu_circuits[qpu_id] = local_qc

        for op in local_operations:
            qpu_id = op.qpu
            qc = qpu_circuits[qpu_id]
            phys_qubits = [logical_to_physical[q][1] for q in op.logical_qubits]
            self._apply_gate(qc, op.gate, phys_qubits, op.params)

        network_stats = {
            "total_links": len(topology.links),
            "links": [l.to_dict() for l in topology.links]
        }

        return CompiledDQC(
            qpu_circuits=qpu_circuits,
            logical_to_qpu=logical_to_qpu,
            logical_to_physical=logical_to_physical,
            remote_operations=remote_operations,
            local_operations=local_operations,
            routes=routes,
            schedule={"makespan": makespan, "timeline": scheduled_ops},
            network_statistics=network_stats,
            resource_statistics=resource_stats,
            original_circuit=circuit
        )

    def _apply_gate(
        self,
        qc: QuantumCircuit,
        gate_name: str,
        phys_qubits: List[int],
        params: List[float]
    ) -> None:
        """Helper to apply a named gate to a Qiskit QuantumCircuit."""
        name = gate_name.lower()
        if name == "h":
            qc.h(phys_qubits[0])
        elif name == "x":
            qc.x(phys_qubits[0])
        elif name == "y":
            qc.y(phys_qubits[0])
        elif name == "z":
            qc.z(phys_qubits[0])
        elif name == "s":
            qc.s(phys_qubits[0])
        elif name == "sdg":
            qc.sdg(phys_qubits[0])
        elif name == "t":
            qc.t(phys_qubits[0])
        elif name == "tdg":
            qc.tdg(phys_qubits[0])
        elif name == "rx":
            qc.rx(params[0] if params else 0.0, phys_qubits[0])
        elif name == "ry":
            qc.ry(params[0] if params else 0.0, phys_qubits[0])
        elif name == "rz":
            qc.rz(params[0] if params else 0.0, phys_qubits[0])
        elif name == "p":
            qc.p(params[0] if params else 0.0, phys_qubits[0])
        elif name == "cx" or name == "cnot":
            qc.cx(phys_qubits[0], phys_qubits[1])
        elif name == "cz":
            qc.cz(phys_qubits[0], phys_qubits[1])
        elif name == "swap":
            qc.swap(phys_qubits[0], phys_qubits[1])
        elif name == "barrier":
            qc.barrier(phys_qubits)
        else:
            if hasattr(qc, name):
                getattr(qc, name)(*phys_qubits)
