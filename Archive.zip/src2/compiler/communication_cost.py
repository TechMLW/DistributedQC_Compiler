from typing import Dict, List, Optional, Any, Union, Tuple
import networkx as nx
from compiler.router import ShortestPathRouter, BaseRouter


class CommunicationCost:
    """
    Computes total communication cost across all inter-QPU interactions in a distributed circuit.
    Evaluates complete multi-hop path costs across all traversed edges.
    """

    def __init__(
        self,
        monitor: Optional[Any] = None,
        router: Optional[BaseRouter] = None,
        alpha: float = 1.0,
        beta: float = 1.0,
        gamma: float = 1.0,
        delta: float = 1.0,
        epsilon: float = 1.0
    ):
        self.monitor = monitor
        self.router = router if router is not None else ShortestPathRouter(
            alpha=alpha, beta=beta, gamma=gamma, delta=delta, epsilon=epsilon
        )
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.epsilon = epsilon

    def calculate(
        self,
        graph: nx.Graph,
        partitions: Union[Dict[int, List[int]], Dict[int, int]],
        topology: Optional[Any] = None
    ) -> float:
        """
        Calculate total communication cost for all cross-QPU interactions in the interaction graph.
        Accounts for interaction frequency (edge weight) and full multi-hop path costs.
        Supports partitions formatted either as {qpu: [qubits]} or {qubit: qpu}.
        """
        # Qubit -> QPU lookup
        qubit_to_qpu: Dict[int, int] = {}
        for k, v in partitions.items():
            if isinstance(v, (list, tuple, set)):
                for q in v:
                    qubit_to_qpu[q] = k
            else:
                qubit_to_qpu[k] = v

        total_comm_cost = 0.0

        # Choose network source: topology or monitor
        net_source = topology if topology is not None else self.monitor

        for u, v, data in graph.edges(data=True):
            if u not in qubit_to_qpu or v not in qubit_to_qpu:
                continue

            qpu1 = qubit_to_qpu[u]
            qpu2 = qubit_to_qpu[v]

            if qpu1 == qpu2:
                # Local interaction within the same QPU (zero inter-QPU cost)
                continue

            weight = data.get("weight", 1)

            # If no network model is attached, cost is simply the cut weight
            if net_source is None:
                total_comm_cost += weight
                continue

            try:
                # Route path across the multi-QPU network
                path = self.router.route(net_source, qpu1, qpu2)
                # Compute path cost across all edges
                path_cost = self.router.calculate_path_cost(
                    net_source,
                    path,
                    alpha=self.alpha,
                    beta=self.beta,
                    gamma=self.gamma,
                    delta=self.delta,
                    epsilon=self.epsilon
                )
                total_comm_cost += weight * path_cost
            except Exception:
                # If disconnected or error, apply disconnection penalty
                total_comm_cost += weight * 1000.0

        return total_comm_cost


    def evaluate_partition(
        self,
        graph: nx.Graph,
        partitions: Union[Dict[int, List[int]], Dict[int, int]],
        topology: Optional[Any] = None,
        max_rounds: int = 3
    ) -> tuple[float, Dict[Tuple[int, int], List[int]], Any]:
        """
        Evaluate a partition against the current network state without mutating it.

        The method jointly considers route choice and demand-derived congestion.
        It iterates a small number of times: route using the current link state,
        accumulate demand weighted by interaction frequency, then route again using
        the resulting congestion. A deep-copied topology keeps candidate evaluation
        isolated from the live simulation state.
        """
        from copy import deepcopy

        net_source = topology if topology is not None else self.monitor
        if net_source is None:
            return self.calculate(graph, partitions, topology=None), {}, None

        work_topology = deepcopy(net_source)

        qubit_to_qpu: Dict[int, int] = {}
        for k, v in partitions.items():
            if isinstance(v, (list, tuple, set)):
                for q in v:
                    qubit_to_qpu[int(q)] = int(k)
            else:
                qubit_to_qpu[int(k)] = int(v)

        routes: Dict[Tuple[int, int], List[int]] = {}
        previous: Optional[Dict[Tuple[int, int], List[int]]] = None

        for _ in range(max(1, int(max_rounds))):
            current: Dict[Tuple[int, int], List[int]] = {}
            weighted_routes = []

            for u, v, data in graph.edges(data=True):
                qpu_u = qubit_to_qpu.get(u)
                qpu_v = qubit_to_qpu.get(v)
                if qpu_u is None or qpu_v is None or qpu_u == qpu_v:
                    continue

                path = self.router.route(work_topology, qpu_u, qpu_v)
                key = (min(u, v), max(u, v))
                current[key] = path
                weighted_routes.append((path, float(data.get("weight", 1))))

            if current == previous:
                routes = current
                break

            routes = current
            work_topology.recalculate_weighted_demand_from_routes(weighted_routes)
            previous = current

        total = 0.0
        for u, v, data in graph.edges(data=True):
            qpu_u = qubit_to_qpu.get(u)
            qpu_v = qubit_to_qpu.get(v)
            if qpu_u is None or qpu_v is None or qpu_u == qpu_v:
                continue
            key = (min(u, v), max(u, v))
            path = routes.get(key)
            if path:
                total += float(data.get("weight", 1)) * self.router.calculate_path_cost(
                    work_topology, path
                )
            else:
                total += float(data.get("weight", 1)) * 1000.0

        return total, routes, work_topology

    def calculate_from_remote_operations(
        self,
        remote_operations: List[Any],
        topology: Optional[Any] = None
    ) -> float:
        """
        Calculate total communication cost directly from a list of RemoteOperation instances.
        """
        total_cost = 0.0
        net_source = topology if topology is not None else self.monitor
        for op in remote_operations:
            if op.cost is not None:
                total_cost += op.cost
            elif op.path and net_source is not None:
                cost = self.router.calculate_path_cost(net_source, op.path)
                total_cost += cost
            else:
                total_cost += 1.0
        return total_cost