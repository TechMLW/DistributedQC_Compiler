import os
import random
from qiskit import QuantumCircuit

from network.topology import Topology
from network.monitor import NetworkMonitor
from compiler.analyzer import CircuitAnalyzer
from compiler.communication_graph import CommunicationGraph
from compiler.kl_partitioner import KLPartitioner
from compiler.router import ShortestPathRouter
from compiler.communication_cost import CommunicationCost
from compiler.compiler import DQCCompiler
from compiler.validator import SemanticValidator
from compiler.optimizer import Optimizer
from compiler.repartition_trigger import RepartitionTrigger
from compiler.simulation import AdaptiveSimulator

# The only fixed experimental parameters. Everything else (when congestion
# occurs, which link is affected, whether/when a repartition happens, and
# what the final partition looks like) is discovered at runtime from the
# live network and compiler state.
INITIAL_BELL_PAIRS_PER_LINK = 50
NUM_SIMULATION_STEPS = 50
RANDOM_SEED = 42

GRAPH_DIR = "graph"
RESULTS_CSV = "simulation_results.csv"
EVENTS_CSV = "repartition_events.csv"


def build_benchmark_circuit(num_qubits: int = 6) -> QuantumCircuit:
    """
    A fixed benchmark workload circuit with distinct interaction clusters.
    This defines the computational task the compiler must partition -- it is
    not part of the network/repartition scenario, which is left entirely to
    runtime network evolution and the adaptive control loop.
    """
    qc = QuantumCircuit(num_qubits, name="Benchmark_Workload_Circuit")
    for i in range(num_qubits):
        qc.h(i)

    for _ in range(4):
        qc.cx(0, 2)
        qc.cx(1, 3)
        qc.cx(4, 5)

    qc.cx(0, 1)
    qc.cx(2, 4)
    qc.cx(3, 5)

    return qc


def clean_output_dir(path: str) -> None:
    """Remove stale generated images from previous runs before starting a fresh one."""
    if os.path.exists(path):
        for f in os.listdir(path):
            if f.endswith(".png"):
                os.remove(os.path.join(path, f))
    else:
        os.makedirs(path, exist_ok=True)


def clean_stale_csv(*paths: str) -> None:
    for path in paths:
        if os.path.exists(path):
            os.remove(path)


def main():
    print("=================================================================")
    print("    DISTRIBUTED QUANTUM COMPUTING (DQC) COMPILER EXPERIMENT      ")
    print("    ADAPTIVE CONGESTION & REPARTITION SIMULATION                 ")
    print("=================================================================\n")

    clean_output_dir(GRAPH_DIR)
    clean_stale_csv(RESULTS_CSV, EVENTS_CSV)

    # 1. Benchmark Circuit
    qc = build_benchmark_circuit(num_qubits=6)
    print("=== 1. Input Quantum Circuit ===")
    print(qc)

    # 2. Circuit Analysis
    analyzer = CircuitAnalyzer()
    analysis = analyzer.analyze(qc)
    print("\n=== 2. Circuit Analysis ===")
    for k, v in analysis.items():
        if k != "gate_sequence":
            print(f"  {k}: {v}")

    # 3. Communication Interaction Graph
    cg_builder = CommunicationGraph(output_dir=GRAPH_DIR)
    comm_graph = cg_builder.build(qc)
    print("\n=== 3. Communication Graph ===")
    for u, v, data in comm_graph.edges(data=True):
        print(f"  Logical Qubit {u} <--> Logical Qubit {v} | Weight = {data.get('weight', 1)}")

    # 4. Authoritative Multi-QPU Network Topology
    print("\n=== 4. Authoritative Multi-QPU Network Topology ===")
    num_qpus = 3
    qpu_capacity = 2
    topology = Topology.create_line_topology(
        num_qpus=num_qpus,
        qpu_capacity=qpu_capacity,
        latency=15.0,
        fidelity=0.98,
        bell_pairs=INITIAL_BELL_PAIRS_PER_LINK,
        capacity=2.0
    )
    topology.print_topology()

    rng = random.Random(RANDOM_SEED)
    monitor = NetworkMonitor(topology=topology, rng=rng)

    router = ShortestPathRouter(alpha=1.0, beta=1.0, gamma=1.0, delta=1.0, epsilon=1.0)
    compiler = DQCCompiler(
        partitioner=KLPartitioner(seed=RANDOM_SEED),
        router=router,
        protocol="telegate"
    )

    trigger = RepartitionTrigger(
        latency_limit=20.0,
        fidelity_limit=0.95,
        congestion_limit=60.0,
        bellpair_limit=15
    )
    optimizer = Optimizer(monitor=monitor)
    cost_calc = CommunicationCost(monitor=monitor, router=router)
    validator = SemanticValidator(tolerance=1e-5)

    capacities = {qpu_id: qpu.capacity for qpu_id, qpu in topology.qpus.items()}

    sim = AdaptiveSimulator(
        compiler=compiler,
        topology=topology,
        circuit=qc,
        comm_graph=comm_graph,
        monitor=monitor,
        trigger=trigger,
        optimizer=optimizer,
        cost_calc=cost_calc,
        capacities=capacities,
        graph_builder=cg_builder,
        image_dir=GRAPH_DIR,
        improvement_threshold=10.0,
        validator=validator,
        verbose=True
    )

    # PHASE A: establish the initial baseline state via the real compiler
    # pipeline (the partitioner chooses the initial partition -- it is not
    # preselected). No repartition decision is made yet, even if this
    # baseline is congested.
    print("\n=== 5. Phase A: Initial Baseline Compilation ===")
    sim.establish_baseline()
    sim.current_compiled.print_summary()
    print(f"\nInitial Communication Cost: {sim.baseline_cost:.3f}")
    print(f"Initial Max Congestion:     {sim.baseline_max_congestion:.1f}%")

    val_res = validator.validate(qc, sim.current_compiled)
    print(f"\nInitial Semantic Validation: {val_res}")

    # PHASE B: adaptive simulation loop
    print("\n=================================================================")
    print(f"    ADAPTIVE SIMULATION LOOP ({NUM_SIMULATION_STEPS} STEPS)                          ")
    print("=================================================================")
    sim.run(NUM_SIMULATION_STEPS)

    sim.finalize()
    sim.write_csv(RESULTS_CSV, EVENTS_CSV)

    print()
    sim.print_summary(NUM_SIMULATION_STEPS, INITIAL_BELL_PAIRS_PER_LINK)

    generated_files = sorted([f for f in os.listdir(GRAPH_DIR) if f.endswith(".png")])
    print(f"\nGenerated Images in '{GRAPH_DIR}/':")
    for f in generated_files:
        print(f"  - {GRAPH_DIR}/{f}")
    print(f"\nGenerated Data Files:")
    print(f"  - {RESULTS_CSV} ({len(sim.step_results)} rows)")
    print(f"  - {EVENTS_CSV} ({len(sim.repartition_events)} rows)")
    print("=================================================================\n")


if __name__ == "__main__":
    main()
