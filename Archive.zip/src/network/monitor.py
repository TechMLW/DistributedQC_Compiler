from typing import Dict, Tuple, Optional, List, Any
import random
from network.link import Link


class NetworkMonitor:
    """
    Observer and dynamic telemetry interface over the authoritative Topology.
    Ensures that all monitored link states, demands, utilizations, and environmental metrics
    are synchronized with the underlying Link objects and Topology graph.
    """

    def __init__(self, topology: Optional[Any] = None, rng: Optional[random.Random] = None):
        if topology is not None:
            self.topology = topology
        else:
            # Create internal fallback Topology
            from network.topology import Topology
            self.topology = Topology()

        # Seeded RNG used exclusively by update() for reproducible environment evolution.
        # Falls back to an unseeded Random() so ad-hoc/test usage is unaffected.
        self.rng = rng if rng is not None else random.Random()

        # Snapshot of each link's latency/fidelity/capacity at the moment the
        # monitor was attached to the topology. update() reverts toward these
        # values so multi-step evolution is a bounded, mean-reverting walk
        # rather than an unbounded (and, if the per-step noise is asymmetric,
        # systematically biased) drift.
        self._baseline: Dict[Tuple[int, int], Dict[str, float]] = {
            (link.source, link.destination): {
                "latency": link.latency,
                "fidelity": link.fidelity,
                "capacity": link.capacity
            }
            for link in self.topology.links
        }

    def attach_topology(self, topology: Any) -> None:
        """Attach an authoritative Topology instance to the monitor."""
        self.topology = topology
        self._baseline = {
            (link.source, link.destination): {
                "latency": link.latency,
                "fidelity": link.fidelity,
                "capacity": link.capacity
            }
            for link in self.topology.links
        }

    @property
    def links(self) -> Dict[Tuple[int, int], dict]:
        """
        Return current link state dictionary dynamically extracted from the authoritative Topology.
        Guarantees that NetworkMonitor and Topology/Link never desynchronize.
        """
        return {
            (link.source, link.destination): link.to_dict()
            for link in self.topology.links
        }

    def register_link(
        self,
        source: int,
        destination: int,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        congestion: Optional[float] = None,
        capacity: float = 10.0,
        demand: float = 0.0
    ) -> Link:
        """Register or update a link in the authoritative topology."""
        existing = self.topology.get_link(source, destination)
        if existing is not None:
            self.topology.update_link(
                source=source,
                destination=destination,
                latency=latency,
                fidelity=fidelity,
                bell_pairs=bell_pairs,
                capacity=capacity,
                demand=demand,
                congestion=congestion
            )
            return existing
        else:
            # Ensure QPUs exist in topology
            if source not in self.topology.qpus:
                self.topology.add_qpu(source, capacity=4)
            if destination not in self.topology.qpus:
                self.topology.add_qpu(destination, capacity=4)

            return self.topology.connect(
                a=source,
                b=destination,
                latency=latency,
                fidelity=fidelity,
                bell_pairs=bell_pairs,
                capacity=capacity,
                demand=demand,
                congestion=congestion
            )

    def get_state(self, source: int, destination: int) -> Optional[dict]:
        """Get the current authoritative state of a link in either direction."""
        link = self.topology.get_link(source, destination)
        if link is not None:
            return link.to_dict()
        return None

    def update_demand(
        self,
        source: int,
        destination: int,
        demand: float,
        queue_len: int = 0
    ) -> None:
        """Update link demand and recompute utilization and congestion on authoritative link."""
        self.topology.update_link(source, destination, demand=demand)

    def consume_bell_pair(self, source: int, destination: int, count: int = 1) -> bool:
        """Consume Bell pairs for an active communication link."""
        link = self.topology.get_link(source, destination)
        if link is not None:
            return link.consume_bell_pair(count)
        return False

    def recalculate_from_routes(self, routes: List[List[int]]) -> None:
        """
        Recalculate demand, utilization, and congestion across all links
        based on active routed multi-hop paths.
        """
        self.topology.recalculate_demand_from_routes(routes)

    def reset_resources(self) -> None:
        """Reset Bell pairs and demands back to initial configuration."""
        self.topology.reset_resources()

    def apply_environmental_change(
        self,
        source: int,
        destination: int,
        latency: Optional[float] = None,
        fidelity: Optional[float] = None,
        bell_pairs: Optional[int] = None,
        capacity: Optional[float] = None,
        demand: Optional[float] = None,
        congestion: Optional[float] = None
    ) -> None:
        """Apply an environmental network perturbation directly to the authoritative Link."""
        self.topology.update_link(
            source=source,
            destination=destination,
            latency=latency,
            fidelity=fidelity,
            bell_pairs=bell_pairs,
            capacity=capacity,
            demand=demand,
            congestion=congestion
        )

    def update(
        self,
        latency_jitter: Tuple[float, float] = (-3.0, 3.0),
        fidelity_jitter: Tuple[float, float] = (-0.01, 0.01),
        bell_pair_jitter: Tuple[int, int] = (-3, 3),
        capacity_jitter: Tuple[float, float] = (-1.0, 1.0),
        reversion_rate: float = 0.1
    ) -> None:
        """
        Generic stochastic environment step: every link's latency, fidelity,
        and capacity follow a bounded, mean-reverting random walk (an equal
        pull back toward that link's own baseline value plus symmetric,
        zero-mean noise) so the environment wanders realistically without
        ever being biased to drift in one direction over many steps -- a
        systematic drift would itself be a hidden, hardcoded scenario
        ("this link always gets worse"), which is exactly what this model
        must avoid. Bell pairs may regenerate or deplete within their
        original provisioning. All perturbation is driven entirely by this
        monitor's seeded RNG and applied directly to the authoritative Link
        objects -- no link or step index is singled out here.
        """
        for link in self.topology.links:
            base = self._baseline.get(
                (link.source, link.destination),
                {"latency": link.latency, "fidelity": link.fidelity, "capacity": link.capacity}
            )

            new_lat = link.latency + reversion_rate * (base["latency"] - link.latency) + self.rng.uniform(*latency_jitter)
            new_fid = link.fidelity + reversion_rate * (base["fidelity"] - link.fidelity) + self.rng.uniform(*fidelity_jitter)
            new_cap = link.capacity + reversion_rate * (base["capacity"] - link.capacity) + self.rng.uniform(*capacity_jitter)
            new_bell = link.bell_pairs + self.rng.randint(*bell_pair_jitter)

            new_lat = max(1.0, new_lat)
            new_fid = max(0.80, min(1.0, new_fid))
            new_cap = max(1.0, new_cap)
            # Bell pairs may regenerate or deplete, but never exceed the link's
            # original provisioning and never drop below zero.
            new_bell = max(0, min(link.initial_bell_pairs, new_bell))

            self.topology.update_link(
                source=link.source,
                destination=link.destination,
                latency=new_lat,
                fidelity=new_fid,
                bell_pairs=new_bell,
                capacity=new_cap
            )

    def print_state(self) -> None:
        """Print formatted current network state."""
        print("\n===== Network State =====")
        for link in self.topology.links:
            print(
                f"({link.source}, {link.destination}) | "
                f"Latency={link.latency:.1f} ms | "
                f"Fidelity={link.fidelity:.3f} | "
                f"BellPairs={link.bell_pairs}/{link.initial_bell_pairs} | "
                f"Demand={link.demand:.1f}/{link.capacity:.1f} | "
                f"Utilization={link.utilization:.2f} | "
                f"Congestion={link.congestion:.1f}%"
            )