from typing import Dict, List, Optional, Tuple, Any
import networkx as nx
from network.qpu import QPU
from network.link import Link


class Topology:
    """
    Manages the authoritative multi-QPU network topology, intra-QPU physical coupling,
    and inter-QPU communication links.
    """

    def __init__(self):
        self.qpus: Dict[int, QPU] = {}
        self.links: List[Link] = []
        self._link_map: Dict[Tuple[int, int], Link] = {}
        self.graph: nx.Graph = nx.Graph()

    def add_qpu(
        self,
        id: int,
        capacity: int,
        topology_type: str = "all_to_all",
        coupling_graph: Optional[nx.Graph] = None
    ) -> QPU:
        """Add a QPU to the topology."""
        qpu = QPU(id, capacity, topology_type=topology_type, coupling_graph=coupling_graph)
        self.qpus[id] = qpu
        self.graph.add_node(id, capacity=capacity, qpu=qpu)
        return qpu

    def connect(
        self,
        a: int,
        b: int,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0,
        demand: float = 0.0,
        congestion: Optional[float] = None
    ) -> Link:
        """Connect two QPUs with a bidirectional inter-QPU communication link."""
        link = Link(
            source=a,
            destination=b,
            latency=latency,
            fidelity=fidelity,
            bell_pairs=bell_pairs,
            capacity=capacity,
            demand=demand,
            congestion=congestion
        )
        self.links.append(link)
        self._link_map[(a, b)] = link
        self._link_map[(b, a)] = link

        self.graph.add_edge(
            a,
            b,
            link=link,
            weight=latency,
            latency=latency,
            fidelity=fidelity,
            bell_pairs=bell_pairs,
            capacity=capacity,
            demand=demand,
            utilization=link.utilization,
            congestion=link.congestion
        )
        return link

    def get_link(self, a: int, b: int) -> Optional[Link]:
        """Get the Link instance between two QPUs, if connected."""
        return self._link_map.get((a, b))

    def update_link(
        self,
        source: int,
        destination: int,
        latency: Optional[float] = None,
        fidelity: Optional[float] = None,
        bell_pairs: Optional[int] = None,
        capacity: Optional[float] = None,
        demand: Optional[float] = None,
        congestion: Optional[float] = None
    ) -> Optional[Link]:
        """Update properties of an existing link on the authoritative topology."""
        link = self.get_link(source, destination)
        if link is not None:
            if latency is not None:
                link.latency = float(latency)
            if fidelity is not None:
                link.fidelity = float(fidelity)
            if bell_pairs is not None:
                link.bell_pairs = int(bell_pairs)
            if capacity is not None:
                link.capacity = max(1.0, float(capacity))
                link.update_demand(link.demand)
            if demand is not None:
                link.update_demand(demand)
            if congestion is not None:
                link.congestion = float(congestion)

            if self.graph.has_edge(source, destination):
                edge_data = self.graph[source][destination]
                edge_data["latency"] = link.latency
                edge_data["fidelity"] = link.fidelity
                edge_data["bell_pairs"] = link.bell_pairs
                edge_data["capacity"] = link.capacity
                edge_data["demand"] = link.demand
                edge_data["utilization"] = link.utilization
                edge_data["congestion"] = link.congestion
                edge_data["weight"] = link.latency
        return link

    def recalculate_demand_from_routes(self, routes: List[List[int]]) -> None:
        """
        Authoritative calculation of link demand and congestion from active routed multi-hop paths.
        For every route [Q0, Q1, ..., Qk], every traversed edge (Q0-Q1, Q1-Q2, ...) receives demand.
        demand_e = count of active routes using edge e
        utilization_e = demand_e / capacity_e
        congestion_e = utilization_e * 100.0  (uncapped -- overload stays visible)
        """
        # 1. Reset demand on all links
        for link in self.links:
            link.demand = 0.0
            link.queue = 0

        # 2. Accumulate demand across each traversed edge along paths
        for path in routes:
            if not path or len(path) < 2:
                continue
            for i in range(len(path) - 1):
                u, v = path[i], path[i + 1]
                link = self.get_link(u, v)
                if link is not None:
                    link.demand += 1.0

        # 3. Update utilization and congestion for all links and sync with graph
        for link in self.links:
            queue_len = max(0, int(link.demand - link.capacity)) if link.demand > link.capacity else 0
            link.update_demand(link.demand, queue_len=queue_len)

            if self.graph.has_edge(link.source, link.destination):
                edge_data = self.graph[link.source][link.destination]
                edge_data["demand"] = link.demand
                edge_data["utilization"] = link.utilization
                edge_data["congestion"] = link.congestion
                edge_data["queue"] = link.queue

    def reset_resources(self) -> None:
        """Reset all link Bell-pair consumption and demand back to initial state."""
        for link in self.links:
            link.reset_resources()
            if self.graph.has_edge(link.source, link.destination):
                edge_data = self.graph[link.source][link.destination]
                edge_data["bell_pairs"] = link.bell_pairs
                edge_data["demand"] = link.demand
                edge_data["utilization"] = link.utilization
                edge_data["congestion"] = link.congestion
        for qpu in self.qpus.values():
            qpu.clear_assignment()

    def get_total_bell_pairs(self) -> Tuple[int, int, int]:
        """Returns (initial_total, consumed_total, remaining_total) across all links."""
        initial = sum(link.initial_bell_pairs for link in self.links)
        consumed = sum(link.consumed_bell_pairs for link in self.links)
        remaining = sum(link.bell_pairs for link in self.links)
        return initial, consumed, remaining

    def get_link_states(self) -> Dict[Tuple[int, int], dict]:
        """Return a mapping of (source, dest) -> link state dict for all links."""
        return {
            (link.source, link.destination): link.to_dict()
            for link in self.links
        }

    @classmethod
    def create_line_topology(
        cls,
        num_qpus: int,
        qpu_capacity: int = 4,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0
    ) -> "Topology":
        """Factory helper: Create a line topology of N QPUs."""
        topo = cls()
        for i in range(num_qpus):
            topo.add_qpu(i, qpu_capacity)
        for i in range(num_qpus - 1):
            topo.connect(i, i + 1, latency=latency, fidelity=fidelity, bell_pairs=bell_pairs, capacity=capacity)
        return topo

    @classmethod
    def create_ring_topology(
        cls,
        num_qpus: int,
        qpu_capacity: int = 4,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0
    ) -> "Topology":
        """Factory helper: Create a ring topology of N QPUs."""
        topo = cls()
        for i in range(num_qpus):
            topo.add_qpu(i, qpu_capacity)
        for i in range(num_qpus):
            topo.connect(i, (i + 1) % num_qpus, latency=latency, fidelity=fidelity, bell_pairs=bell_pairs, capacity=capacity)
        return topo

    @classmethod
    def create_mesh_topology(
        cls,
        num_qpus: int,
        qpu_capacity: int = 4,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0
    ) -> "Topology":
        """Factory helper: Create an all-to-all mesh topology of N QPUs."""
        topo = cls()
        for i in range(num_qpus):
            topo.add_qpu(i, qpu_capacity)
        for i in range(num_qpus):
            for j in range(i + 1, num_qpus):
                topo.connect(i, j, latency=latency, fidelity=fidelity, bell_pairs=bell_pairs, capacity=capacity)
        return topo

    @classmethod
    def create_star_topology(
        cls,
        num_qpus: int,
        center_qpu: int = 0,
        qpu_capacity: int = 4,
        latency: float = 15.0,
        fidelity: float = 0.98,
        bell_pairs: int = 20,
        capacity: float = 10.0
    ) -> "Topology":
        """Factory helper: Create a star topology with a central QPU."""
        topo = cls()
        for i in range(num_qpus):
            topo.add_qpu(i, qpu_capacity)
        for i in range(num_qpus):
            if i != center_qpu:
                topo.connect(center_qpu, i, latency=latency, fidelity=fidelity, bell_pairs=bell_pairs, capacity=capacity)
        return topo

    def print_topology(self) -> None:
        """Print human-readable topology summary."""
        print("\n===== TOPOLOGY =====")
        for qpu in self.qpus.values():
            print(qpu)
        print()
        for link in self.links:
            print(link)