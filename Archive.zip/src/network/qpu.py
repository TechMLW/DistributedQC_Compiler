from typing import List, Optional, Dict
import networkx as nx


class QPU:
    """
    Represents a single Quantum Processing Unit (QPU) in a Distributed Quantum Computing system.
    
    Attributes:
        id: Unique identifier of the QPU.
        capacity: Maximum number of physical/logical qubits this QPU can host.
        logical_qubits: List of logical qubit IDs assigned to this QPU.
        coupling_graph: NetworkX Graph representing the physical qubit connectivity on the QPU.
        physical_mapping: Dict mapping assigned logical qubit ID -> physical qubit ID on this QPU.
    """

    def __init__(
        self,
        id: int,
        capacity: int,
        topology_type: str = "all_to_all",
        coupling_graph: Optional[nx.Graph] = None
    ):
        self.id = id
        self.capacity = capacity
        self.logical_qubits: List[int] = []
        self.physical_mapping: Dict[int, int] = {}  # logical_qubit -> physical_qubit

        if coupling_graph is not None:
            self.coupling_graph = coupling_graph
        else:
            self.coupling_graph = self._create_coupling_graph(topology_type, capacity)

    def _create_coupling_graph(self, topology_type: str, num_qubits: int) -> nx.Graph:
        """Create a physical coupling graph for the QPU's internal physical qubits."""
        g = nx.Graph()
        g.add_nodes_from(range(num_qubits))

        if topology_type == "all_to_all":
            for i in range(num_qubits):
                for j in range(i + 1, num_qubits):
                    g.add_edge(i, j)
        elif topology_type == "line":
            for i in range(num_qubits - 1):
                g.add_edge(i, i + 1)
        elif topology_type == "ring":
            for i in range(num_qubits):
                g.add_edge(i, (i + 1) % num_qubits)
        elif topology_type == "grid":
            # 2D Grid if possible, else line
            import math
            cols = int(math.ceil(math.sqrt(num_qubits)))
            for i in range(num_qubits):
                r = i // cols
                c = i % cols
                if c + 1 < cols and (i + 1) < num_qubits:
                    g.add_edge(i, i + 1)
                if (i + cols) < num_qubits:
                    g.add_edge(i, i + cols)
        else:
            # Default to all-to-all
            for i in range(num_qubits):
                for j in range(i + 1, num_qubits):
                    g.add_edge(i, j)

        return g

    def assign(self, qubit: int) -> bool:
        """Assign a logical qubit to this QPU if capacity allows."""
        if len(self.logical_qubits) < self.capacity and qubit not in self.logical_qubits:
            self.logical_qubits.append(qubit)
            return True
        return False

    def clear_assignment(self) -> None:
        """Clear logical qubit assignments and physical mapping."""
        self.logical_qubits.clear()
        self.physical_mapping.clear()

    def set_physical_mapping(self, mapping: Dict[int, int]) -> None:
        """Set logical to physical qubit mapping for this QPU."""
        self.physical_mapping = dict(mapping)

    def is_physically_connected(self, phys_q1: int, phys_q2: int) -> bool:
        """Check if two physical qubits have a direct coupling on this QPU."""
        return self.coupling_graph.has_edge(phys_q1, phys_q2)

    def __str__(self) -> str:
        mapping_str = f", Mapping={self.physical_mapping}" if self.physical_mapping else ""
        return f"QPU {self.id} | Capacity={self.capacity} | Qubits={self.logical_qubits}{mapping_str}"