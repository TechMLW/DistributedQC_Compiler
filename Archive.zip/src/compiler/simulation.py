"""
Generic adaptive DQC simulation engine.

Implements the state-dependent control loop described by the experiment protocol:

    network evolves -> actual communication demand is measured -> congestion is
    calculated -> repartition trigger is evaluated -> candidate partition is
    evaluated -> accept only if it is actually better -> update compiler/network
    state -> continue

Nothing here hardcodes *when* congestion occurs, *which* link becomes congested,
*when* a repartition happens, or *what* the final partition looks like. All of
that is discovered from the live state of the Topology/Link objects and the
compiler/optimizer components handed to this class at construction time.

The decision pipeline (`evaluate_and_maybe_repartition`) is deliberately
separate from network evolution (`NetworkMonitor.update`, invoked by
`run_step`) so that unit tests can drive the pipeline against a hand-built
network state without depending on randomness.
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import csv
import statistics

from qiskit import QuantumCircuit

from compiler.optimizer import Optimizer
from compiler.communication_cost import CommunicationCost
from compiler.repartition_trigger import RepartitionTrigger
from compiler.communication_graph import CommunicationGraph
from compiler.compiler import DQCCompiler
from compiler.scheduler import SchedulingError
from compiler.validator import SemanticValidator
from network.topology import Topology
from network.monitor import NetworkMonitor


@dataclass
class StepResult:
    step: int
    triggered: bool
    trigger_reason: str
    optimizer_run: bool
    partition_changed: bool
    accepted: bool
    current_cost_before: float
    candidate_cost: Optional[float]
    current_cost_after: float
    remote_operations: int
    max_congestion: float
    avg_congestion: float
    max_link_utilization: float
    total_bell_pairs_available: int
    total_bell_pairs_consumed: int
    routes_changed: int
    logical_qubits_moved: int


@dataclass
class RepartitionEvent:
    event_id: int
    step: int
    old_partition: Dict[int, List[int]]
    new_partition: Dict[int, List[int]]
    old_cost: float
    new_cost: float
    logical_qubits_moved: int
    old_remote_operations: int
    new_remote_operations: int
    old_max_congestion: float
    new_max_congestion: float


class AdaptiveSimulator:
    """
    Drives Phase A (initial baseline compile) followed by an N-step adaptive
    control loop over a single authoritative Topology. All decisions are
    derived from the live state of the components passed in; the simulator
    itself carries no scenario, threshold-crossing schedule, or expected
    outcome.
    """

    def __init__(
        self,
        compiler: DQCCompiler,
        topology: Topology,
        circuit: QuantumCircuit,
        comm_graph: Any,
        monitor: NetworkMonitor,
        trigger: RepartitionTrigger,
        optimizer: Optimizer,
        cost_calc: CommunicationCost,
        capacities: Dict[int, int],
        graph_builder: Optional[CommunicationGraph] = None,
        image_dir: str = "graph",
        improvement_threshold: float = 10.0,
        validator: Optional[SemanticValidator] = None,
        verbose: bool = False
    ):
        self.compiler = compiler
        self.topology = topology
        self.circuit = circuit
        self.comm_graph = comm_graph
        self.monitor = monitor
        self.trigger = trigger
        self.optimizer = optimizer
        self.cost_calc = cost_calc
        self.capacities = capacities
        self.graph_builder = graph_builder or CommunicationGraph(output_dir=image_dir)
        self.image_dir = image_dir
        self.improvement_threshold = improvement_threshold
        self.validator = validator
        self.verbose = verbose

        self.current_partition: Optional[Dict[int, List[int]]] = None
        self.current_compiled = None
        self.baseline_cost: Optional[float] = None
        self.baseline_max_congestion: Optional[float] = None
        self.baseline_remote_operations: Optional[int] = None

        self.step_results: List[StepResult] = []
        self.repartition_events: List[RepartitionEvent] = []

        self.repartition_checks = 0
        self.repartition_triggers = 0
        self.optimizer_runs = 0
        self.actual_repartitions = 0
        self.trigger_events_without_partition_change = 0

        # Fingerprint of the (partition, network, resource) state as of the
        # most recent trigger for which the optimizer concluded "no better
        # candidate exists". If a later trigger fires against an identical
        # fingerprint, re-running the exact same search would reproduce the
        # exact same conclusion, so it is skipped -- this is re-armed the
        # instant anything relevant actually changes (see _state_signature).
        self._last_no_improvement_signature: Optional[tuple] = None

    # ---- Metrics derived strictly from the live Topology -------------------
    def _link_metrics(self) -> Tuple[float, float, float]:
        """Returns (max_congestion, avg_congestion, max_utilization) across all links."""
        links = self.topology.links
        if not links:
            return 0.0, 0.0, 0.0
        congestions = [l.congestion for l in links]
        utilizations = [l.utilization for l in links]
        return max(congestions), statistics.fmean(congestions), max(utilizations)

    def _bell_pair_totals(self) -> Tuple[int, int]:
        available = sum(l.bell_pairs for l in self.topology.links)
        consumed = sum(l.consumed_bell_pairs for l in self.topology.links)
        return available, consumed

    def _current_cost(self) -> float:
        """Always recomputed against the CURRENT partition and CURRENT topology state -- never cached."""
        return self.cost_calc.calculate(self.comm_graph, self.current_partition, topology=self.topology)

    def _state_signature(self) -> tuple:
        """
        Deterministic fingerprint of everything that can change the outcome of
        an optimization search: the current partition plus every link's
        rounded congestion/latency/fidelity/bell-pair/capacity state. Two
        calls return the same tuple iff nothing that the objective function
        or router could see has materially moved -- used to avoid rerunning
        an expensive search against a problem it has already solved.
        """
        partition_sig = tuple(
            (qpu, tuple(sorted(qubits)))
            for qpu, qubits in sorted(self.current_partition.items())
        )
        link_sig = tuple(
            (
                l.source, l.destination,
                round(l.congestion, 1), round(l.latency, 1),
                round(l.fidelity, 4), l.bell_pairs, round(l.capacity, 2)
            )
            for l in sorted(self.topology.links, key=lambda x: (x.source, x.destination))
        )
        return (partition_sig, link_sig)

    # ---- Phase A: establish the initial baseline state ---------------------
    def establish_baseline(self) -> None:
        """
        Compile the circuit once through the real compiler pipeline (partitioner
        included) to establish the INITIAL BASELINE STATE. The resulting
        partition comes entirely from the compiler/partitioner -- it is not
        preselected. No repartition decision is made here, even if the
        baseline turns out to be congested; that evaluation only begins once
        the adaptive loop starts.
        """
        self.current_compiled = self.compiler.compile(self.circuit, topology=self.topology)
        self.current_partition = {
            qpu_id: sorted([q for q, p in self.current_compiled.logical_to_qpu.items() if p == qpu_id])
            for qpu_id in self.topology.qpus
        }
        self.baseline_cost = self._current_cost()
        self.baseline_remote_operations = len(self.current_compiled.remote_operations)
        max_c, _, _ = self._link_metrics()
        self.baseline_max_congestion = max_c

        self.graph_builder.draw(
            self.comm_graph,
            filename="initial_partition.png",
            title="Initial DQC Partition Assignment",
            partitions=self.current_partition,
            subtitle=(
                f"Remote Ops: {self.baseline_remote_operations} | "
                f"Comm Cost: {self.baseline_cost:.3f} | "
                f"Max Congestion: {self.baseline_max_congestion:.1f}%"
            ),
            output_dir=self.image_dir
        )

    # ---- Core decision pipeline (no network evolution here) ----------------
    def evaluate_and_maybe_repartition(self, step_idx: int) -> StepResult:
        """
        One full adaptive decision cycle against whatever the CURRENT topology
        state happens to be: measure current cost, check the trigger, and only
        if triggered, evaluate a candidate partition and accept it if it is
        actually better. Does not itself perturb the network -- callers that
        want the generic stochastic environment step should use `run_step`.
        """
        if self.current_partition is None or self.current_compiled is None:
            raise RuntimeError("establish_baseline() must be called before evaluating steps.")

        self.repartition_checks += 1

        current_cost_before = self._current_cost()
        old_routes = dict(self.current_compiled.routes)
        old_remote_ops = len(self.current_compiled.remote_operations)

        triggered, reason = self.trigger.check(self.topology)

        optimizer_run = False
        candidate_cost: Optional[float] = None
        partition_changed = False
        accepted = False
        logical_qubits_moved = 0
        routes_changed = 0

        if triggered:
            self.repartition_triggers += 1

            # If this exact (partition, network, resource) fingerprint already
            # produced "no better candidate exists" at a previous trigger,
            # rerunning the search would recompute the identical answer --
            # skip it. Re-armed the moment the fingerprint actually changes
            # (network evolution, a prior accepted repartition, etc.).
            signature = self._state_signature()
            if signature == self._last_no_improvement_signature:
                self.trigger_events_without_partition_change += 1
            else:
                self.optimizer_runs += 1
                optimizer_run = True

                max_congestion_before, _, _ = self._link_metrics()

                opt_res = self.optimizer.adaptive_optimize(
                    graph=self.comm_graph,
                    current_partition=self.current_partition,
                    threshold=self.improvement_threshold,
                    topology=self.topology,
                    capacities=self.capacities
                )
                candidate_cost = opt_res.new_cost

                if opt_res.changed:
                    old_partition = self.current_partition

                    # Attempt to actually commit to the candidate partition. This can
                    # fail if the candidate's routes would exceed remaining Bell-pair
                    # resources along some link -- a genuine physical resource
                    # constraint, not a scenario. In that case the candidate is
                    # rejected and the current partition is kept.
                    try:
                        new_compiled = self.compiler.recompile_for_partition(
                            circuit=self.circuit,
                            partitions=opt_res.partition,
                            topology=self.topology,
                            interaction_graph=self.comm_graph
                        )
                    except SchedulingError:
                        new_compiled = None

                    if new_compiled is not None:
                        partition_changed = True
                        accepted = True
                        self.actual_repartitions += 1
                        logical_qubits_moved = len(opt_res.changed_qubits)

                        self.current_partition = opt_res.partition
                        self.current_compiled = new_compiled

                        new_routes = dict(self.current_compiled.routes)
                        all_keys = set(old_routes.keys()) | set(new_routes.keys())
                        routes_changed = sum(1 for k in all_keys if old_routes.get(k) != new_routes.get(k))

                        max_congestion_after, _, _ = self._link_metrics()

                        if self.validator is not None:
                            self.validator.validate(self.circuit, self.current_compiled)

                        image_filename = f"actual_repartition_{self.actual_repartitions:02d}_step_{step_idx:02d}.png"
                        moved_qubits = sorted(opt_res.changed_qubits)
                        self.graph_builder.draw(
                            self.comm_graph,
                            filename=image_filename,
                            title=f"Actual Repartition #{self.actual_repartitions:02d} (Step {step_idx:02d})",
                            partitions=self.current_partition,
                            subtitle=(
                                f"Step {step_idx} | Event #{self.actual_repartitions} | "
                                f"Remote Ops: {len(self.current_compiled.remote_operations)} | "
                                f"Comm Cost: {opt_res.new_cost:.3f} | "
                                f"Max Congestion: {max_congestion_after:.1f}% | "
                                f"Qubits Moved: {moved_qubits}"
                            ),
                            output_dir=self.image_dir
                        )

                        self.repartition_events.append(RepartitionEvent(
                            event_id=self.actual_repartitions,
                            step=step_idx,
                            old_partition={k: sorted(v) for k, v in old_partition.items()},
                            new_partition={k: sorted(v) for k, v in self.current_partition.items()},
                            old_cost=opt_res.old_cost,
                            new_cost=opt_res.new_cost,
                            logical_qubits_moved=logical_qubits_moved,
                            old_remote_operations=old_remote_ops,
                            new_remote_operations=len(self.current_compiled.remote_operations),
                            old_max_congestion=max_congestion_before,
                            new_max_congestion=max_congestion_after
                        ))

                        # The state actually moved -- any previous "no
                        # improvement" fingerprint no longer applies.
                        self._last_no_improvement_signature = None
                    else:
                        # Candidate was better on paper but not physically
                        # realizable right now; nothing about the live state
                        # changed, so remember this fingerprint too.
                        self.trigger_events_without_partition_change += 1
                        self._last_no_improvement_signature = signature
                else:
                    self.trigger_events_without_partition_change += 1
                    self._last_no_improvement_signature = signature

        max_congestion, avg_congestion, max_util = self._link_metrics()
        bell_available, bell_consumed = self._bell_pair_totals()
        current_cost_after = self._current_cost()

        result = StepResult(
            step=step_idx,
            triggered=triggered,
            trigger_reason=reason,
            optimizer_run=optimizer_run,
            partition_changed=partition_changed,
            accepted=accepted,
            current_cost_before=current_cost_before,
            candidate_cost=candidate_cost,
            current_cost_after=current_cost_after,
            remote_operations=len(self.current_compiled.remote_operations),
            max_congestion=max_congestion,
            avg_congestion=avg_congestion,
            max_link_utilization=max_util,
            total_bell_pairs_available=bell_available,
            total_bell_pairs_consumed=bell_consumed,
            routes_changed=routes_changed,
            logical_qubits_moved=logical_qubits_moved
        )
        self.step_results.append(result)

        if self.verbose:
            self._print_step(result)

        return result

    def run_step(self, step_idx: int) -> StepResult:
        """One full adaptive-simulation step: generic network evolution, then the decision pipeline."""
        self.monitor.update()
        return self.evaluate_and_maybe_repartition(step_idx)

    def run(self, num_steps: int) -> List[StepResult]:
        for step_idx in range(1, num_steps + 1):
            self.run_step(step_idx)
        return self.step_results

    def finalize(self) -> None:
        """Render the final partition image after the adaptive loop has completed."""
        max_c, _, _ = self._link_metrics()
        self.graph_builder.draw(
            self.comm_graph,
            filename="final_partition.png",
            title="Final DQC Partition Assignment",
            partitions=self.current_partition,
            subtitle=(
                f"Steps: {len(self.step_results)} | "
                f"Actual Repartitions: {self.actual_repartitions} | "
                f"Max Congestion: {max_c:.1f}%"
            ),
            output_dir=self.image_dir
        )

    # ---- Reporting -----------------------------------------------------------
    def _print_step(self, r: StepResult) -> None:
        print(
            f"[Step {r.step:02d}] triggered={r.triggered} "
            f"optimizer_run={r.optimizer_run} partition_changed={r.partition_changed} "
            f"current_cost={r.current_cost_before:.2f} candidate_cost={'-' if r.candidate_cost is None else f'{r.candidate_cost:.2f}'} "
            f"max_congestion={r.max_congestion:.1f}% remote_ops={r.remote_operations}"
        )
        if r.triggered:
            print(f"           reason: {r.trigger_reason}")

    def write_csv(self, results_path: str, events_path: str) -> None:
        fieldnames = [
            "step", "triggered", "trigger_reason", "optimizer_run", "partition_changed",
            "accepted", "current_cost_before", "candidate_cost", "current_cost_after", "remote_operations",
            "max_congestion", "avg_congestion", "max_link_utilization",
            "total_bell_pairs_available", "total_bell_pairs_consumed",
            "routes_changed", "logical_qubits_moved"
        ]
        with open(results_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in self.step_results:
                writer.writerow({
                    "step": r.step,
                    "triggered": r.triggered,
                    "trigger_reason": r.trigger_reason,
                    "optimizer_run": r.optimizer_run,
                    "partition_changed": r.partition_changed,
                    "accepted": r.accepted,
                    "current_cost_before": f"{r.current_cost_before:.6f}",
                    "candidate_cost": "" if r.candidate_cost is None else f"{r.candidate_cost:.6f}",
                    "current_cost_after": f"{r.current_cost_after:.6f}",
                    "remote_operations": r.remote_operations,
                    "max_congestion": f"{r.max_congestion:.4f}",
                    "avg_congestion": f"{r.avg_congestion:.4f}",
                    "max_link_utilization": f"{r.max_link_utilization:.4f}",
                    "total_bell_pairs_available": r.total_bell_pairs_available,
                    "total_bell_pairs_consumed": r.total_bell_pairs_consumed,
                    "routes_changed": r.routes_changed,
                    "logical_qubits_moved": r.logical_qubits_moved
                })

        event_fieldnames = [
            "event_id", "step", "old_partition", "new_partition", "old_cost", "new_cost",
            "logical_qubits_moved", "old_remote_operations", "new_remote_operations",
            "old_max_congestion", "new_max_congestion"
        ]
        with open(events_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=event_fieldnames)
            writer.writeheader()
            for e in self.repartition_events:
                writer.writerow({
                    "event_id": e.event_id,
                    "step": e.step,
                    "old_partition": e.old_partition,
                    "new_partition": e.new_partition,
                    "old_cost": f"{e.old_cost:.6f}",
                    "new_cost": f"{e.new_cost:.6f}",
                    "logical_qubits_moved": e.logical_qubits_moved,
                    "old_remote_operations": e.old_remote_operations,
                    "new_remote_operations": e.new_remote_operations,
                    "old_max_congestion": f"{e.old_max_congestion:.4f}",
                    "new_max_congestion": f"{e.new_max_congestion:.4f}"
                })

    def print_summary(self, num_steps: int, initial_bell_pairs_per_link: int) -> None:
        final_cost = self._current_cost()
        final_max_congestion, _, _ = self._link_metrics()
        final_remote_ops = len(self.current_compiled.remote_operations)

        print("=================================================================")
        print("                  FINAL EXPERIMENT SUMMARY                       ")
        print("=================================================================")
        print(f"Simulation steps:                             {num_steps}")
        print(f"Initial Bell pairs per link:                  {initial_bell_pairs_per_link}")
        print()
        print(f"Repartition checks:                           {self.repartition_checks}")
        print(f"Repartition triggers:                         {self.repartition_triggers}")
        print(f"Optimizer runs:                                {self.optimizer_runs}")
        print(f"Actual repartitions:                          {self.actual_repartitions}")
        print(f"Triggered but unchanged:                      {self.trigger_events_without_partition_change}")
        print()
        print(f"Initial communication cost:                   {self.baseline_cost:.3f}")
        print(f"Final communication cost:                     {final_cost:.3f}")
        print()
        print(f"Initial remote operations:                    {self.baseline_remote_operations}")
        print(f"Final remote operations:                      {final_remote_ops}")
        print()
        print(f"Initial max congestion:                       {self.baseline_max_congestion:.1f}%")
        print(f"Final max congestion:                         {final_max_congestion:.1f}%")
        print("=================================================================")
