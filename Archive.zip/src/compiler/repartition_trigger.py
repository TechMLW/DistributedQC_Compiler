from typing import Tuple, Any, Optional


class RepartitionTrigger:
    """
    Monitors authoritative network topology links against degradation thresholds
    to determine if repartition optimization should be triggered.
    """

    def __init__(
        self,
        latency_limit: float = 20.0,
        fidelity_limit: float = 0.95,
        congestion_limit: float = 20.0,
        bellpair_limit: int = 10
    ):
        self.latency_limit = float(latency_limit)
        self.fidelity_limit = float(fidelity_limit)
        self.congestion_limit = float(congestion_limit)
        self.bellpair_limit = int(bellpair_limit)

    def check(self, topology_or_monitor: Any) -> Tuple[bool, str]:
        """
        Check all links in the authoritative topology or monitor against thresholds.
        Returns (triggered: bool, reason: str).
        """
        links_data = []
        if hasattr(topology_or_monitor, "links"):
            raw_links = topology_or_monitor.links
            if isinstance(raw_links, list):
                # Topology object with List[Link]
                links_data = [l.to_dict() for l in raw_links]
            elif isinstance(raw_links, dict):
                # Dict of link states
                links_data = list(raw_links.values())

        for state in links_data:
            src = state.get("source", "?")
            dst = state.get("destination", "?")

            if state.get("congestion", 0.0) > self.congestion_limit:
                return True, f"Link ({src}, {dst}) congestion {state['congestion']:.1f}% exceeds limit {self.congestion_limit:.1f}%"

            if state.get("latency", 0.0) > self.latency_limit:
                return True, f"Link ({src}, {dst}) latency {state['latency']:.1f}ms exceeds limit {self.latency_limit:.1f}ms"

            if state.get("fidelity", 1.0) < self.fidelity_limit:
                return True, f"Link ({src}, {dst}) fidelity {state['fidelity']:.3f} below limit {self.fidelity_limit:.3f}"

            if state.get("bell_pairs", 100) < self.bellpair_limit:
                return True, f"Link ({src}, {dst}) Bell pairs {state['bell_pairs']} below limit {self.bellpair_limit}"

        return False, "Network conditions within healthy thresholds"

    def should_repartition(self, topology_or_monitor: Any) -> bool:
        """Boolean check for backward compatibility."""
        triggered, _ = self.check(topology_or_monitor)
        return triggered