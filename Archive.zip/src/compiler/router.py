from typing import List, Optional, Dict, Any, Union
from abc import ABC, abstractmethod
import networkx as nx


class BaseRouter(ABC):
    """
    Abstract Base Class for multi-QPU network routers.
    Defines the standard routing interface to allow seamless plug-and-play
    between Baseline Router, Dynamic Congestion Router, and future SCQR.
    """

    def __init__(
        self,
        alpha: float = 1.0,   # Latency coefficient
        beta: float = 1.0,    # Congestion coefficient
        gamma: float = 1.0,   # Fidelity penalty coefficient
        delta: float = 1.0,   # Bell-pair scarcity coefficient
        epsilon: float = 1.0  # Hop count coefficient
    ):
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.epsilon = epsilon

    @abstractmethod
    def route(
        self,
        topology_or_graph: Any,
        source: int,
        destination: int,
        **kwargs
    ) -> List[int]:
        """
        Find a communication path [source, ..., destination] across the QPU network.
        """
        pass

    def compute_edge_cost(
        self,
        edge_data: dict,
        alpha: Optional[float] = None,
        beta: Optional[float] = None,
        gamma: Optional[float] = None,
        delta: Optional[float] = None,
        epsilon: Optional[float] = None
    ) -> float:
        """
        Calculate cost for a single edge e = (u, v) based on:
        Cost(e) = alpha * Latency + beta * Congestion + gamma * (1 - Fidelity)*100 + delta * (20 / (BellPairs + 1)) + epsilon * Hop
        """
        a = self.alpha if alpha is None else alpha
        b = self.beta if beta is None else beta
        g = self.gamma if gamma is None else gamma
        d = self.delta if delta is None else delta
        e = self.epsilon if epsilon is None else epsilon

        latency = float(edge_data.get("latency", edge_data.get("weight", 15.0)))
        fidelity = float(edge_data.get("fidelity", 0.98))
        bell_pairs = float(edge_data.get("bell_pairs", 20))
        congestion = float(edge_data.get("congestion", 0.0))

        fid_penalty = (1.0 - fidelity) * 100.0
        bell_penalty = 20.0 / (bell_pairs + 1.0)

        return (
            a * latency
            + b * congestion
            + g * fid_penalty
            + d * bell_penalty
            + e
        )

    def calculate_path_cost(
        self,
        topology_or_graph: Any,
        path: List[int],
        **kwargs
    ) -> float:
        """
        Calculate total communication cost over ALL edges along the path P = (e_1, e_2, ..., e_n).
        """
        if not path or len(path) < 2:
            return 0.0

        graph = self._extract_graph(topology_or_graph)
        total_cost = 0.0

        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            if graph.has_edge(u, v):
                edge_data = graph[u][v]
                total_cost += self.compute_edge_cost(edge_data, **kwargs)
            else:
                total_cost += 1e6  # Infinite penalty for disconnected link

        return total_cost

    def _extract_graph(self, topology_or_graph: Any) -> nx.Graph:
        """Helper to extract nx.Graph from either a Topology object, NetworkMonitor, or a raw nx.Graph."""
        if hasattr(topology_or_graph, "graph") and isinstance(topology_or_graph.graph, nx.Graph):
            return topology_or_graph.graph
        if isinstance(topology_or_graph, nx.Graph):
            return topology_or_graph
        if hasattr(topology_or_graph, "links") and isinstance(topology_or_graph.links, dict):
            # Extract from NetworkMonitor
            g = nx.Graph()
            for (u, v), state in topology_or_graph.links.items():
                g.add_edge(u, v, **state)
            return g
        return topology_or_graph


class ShortestPathRouter(BaseRouter):
    """
    Baseline multi-hop network router using Dijkstra's algorithm over
    a composite edge-cost function accounting for latency, congestion, fidelity,
    Bell-pair availability, and hop count across all traversed links.
    """

    def route(
        self,
        topology_or_graph: Any,
        source: int,
        destination: int,
        weight_attribute: Optional[str] = None,
        **kwargs
    ) -> List[int]:
        if source == destination:
            return [source]

        graph = self._extract_graph(topology_or_graph)

        if not graph.has_node(source) or not graph.has_node(destination):
            raise ValueError(f"Source QPU {source} or Destination QPU {destination} not found in topology.")

        # Build weighted graph using compute_edge_cost
        cost_graph = nx.Graph()
        for u, v, data in graph.edges(data=True):
            if weight_attribute and weight_attribute in data:
                edge_w = float(data[weight_attribute])
            else:
                edge_w = self.compute_edge_cost(data)
            cost_graph.add_edge(u, v, weight=edge_w)

        try:
            path = nx.shortest_path(cost_graph, source=source, target=destination, weight="weight")
            return path
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            raise nx.NetworkXNoPath(f"No communication path exists between QPU {source} and QPU {destination}.")


# Alias Router to ShortestPathRouter for complete backward compatibility
Router = ShortestPathRouter

# NOTE [SCQR INTEGRATION POINT]:
# Future Selective Congestion Qubit Routing (SCQR) should inherit from BaseRouter
# (or wrap ShortestPathRouter), e.g.:
#
# class SelectiveCongestionRouter(BaseRouter):
#     def route(...):
#         # 1. Identify congestion threshold violations on default shortest paths
#         # 2. Selectively reroute only congested qubit interaction streams
#         # 3. Leave uncongested routes on baseline shortest paths
#         ...