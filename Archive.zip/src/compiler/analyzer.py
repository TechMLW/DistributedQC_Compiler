from typing import Dict, List, Any
from qiskit import QuantumCircuit
from qiskit.converters import circuit_to_dag


class CircuitAnalyzer:
    """
    Analyzes a Qiskit QuantumCircuit to extract gate statistics, qubit counts,
    depth, two-qubit communication interactions, and sequential gate streams.
    """

    def analyze(self, circuit: QuantumCircuit) -> Dict[str, Any]:
        """
        Perform comprehensive analysis on the input quantum circuit.
        """
        dag = circuit_to_dag(circuit)

        communication = []
        two_qubit_gates = []
        gate_sequence = []

        # Helper to get numeric index of a qubit safely in Qiskit 1.0+ and 2.x
        def get_qubit_index(q):
            try:
                return circuit.find_bit(q).index
            except AttributeError:
                return circuit.qubits.index(q)

        for instruction in circuit.data:
            op = instruction.operation
            q_indices = [get_qubit_index(q) for q in instruction.qubits]
            c_indices = [circuit.find_bit(c).index for c in instruction.clbits] if hasattr(circuit, "clbits") and circuit.clbits else []

            gate_info = {
                "name": op.name,
                "qubits": q_indices,
                "clbits": c_indices,
                "params": list(op.params) if hasattr(op, "params") else [],
                "num_qubits": len(q_indices),
                "is_two_qubit": len(q_indices) == 2,
                "operation": op
            }
            gate_sequence.append(gate_info)

            if len(q_indices) == 2:
                two_qubit_gates.append(gate_info)
                communication.append({
                    "gate": op.name,
                    "qubits": q_indices
                })
            elif len(q_indices) > 2:
                # Multi-qubit gate (>2 qubits)
                communication.append({
                    "gate": op.name,
                    "qubits": q_indices
                })

        ops_dict = {}
        for name, count in circuit.count_ops().items():
            ops_dict[name] = int(count)

        return {
            "qubits": circuit.num_qubits,
            "depth": circuit.depth(),
            "gate_count": circuit.size(),
            "operations": ops_dict,
            "communication_gates": communication,
            "two_qubit_gates": two_qubit_gates,
            "gate_sequence": gate_sequence
        }