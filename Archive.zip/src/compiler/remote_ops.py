from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict
from abc import ABC, abstractmethod


class RemoteGateProtocol(ABC):
    """
    Abstract base class for DQC remote gate execution protocols.
    """

    @abstractmethod
    def bell_pairs_per_hop(self) -> int:
        """Number of Bell pairs consumed per network hop."""
        pass

    @abstractmethod
    def classical_messages_per_hop(self) -> int:
        """Number of classical bit messages sent per hop."""
        pass

    @abstractmethod
    def latency_multiplier(self) -> float:
        """Latency factor applied to link latency."""
        pass

    def calculate_bell_pairs(self, path: List[int]) -> int:
        """Calculate total Bell pairs needed across a multi-hop path."""
        if not path or len(path) < 2:
            return 0
        hops = len(path) - 1
        return hops * self.bell_pairs_per_hop()


class TeleGate(RemoteGateProtocol):
    """
    Non-local gate execution using Cat-state entanglement sharing or gate teleportation.
    Consumes 1 Bell pair per hop and requires 2 rounds of classical communication.
    """

    def bell_pairs_per_hop(self) -> int:
        return 1

    def classical_messages_per_hop(self) -> int:
        return 2

    def latency_multiplier(self) -> float:
        return 1.5


class TeleData(RemoteGateProtocol):
    """
    State teleportation protocol: teleports target/control qubit to destination QPU,
    executes local gate, and teleports back if needed.
    Consumes 2 Bell pairs per hop (forward + backward) and 4 classical messages.
    """

    def bell_pairs_per_hop(self) -> int:
        return 2

    def classical_messages_per_hop(self) -> int:
        return 4

    def latency_multiplier(self) -> float:
        return 2.5


# Protocol Registry
PROTOCOLS: Dict[str, RemoteGateProtocol] = {
    "telegate": TeleGate(),
    "teledata": TeleData()
}


@dataclass
class LocalOperation:
    """
    Represents an intra-QPU quantum operation.
    """
    gate: str
    logical_qubits: List[int]
    qpu: int
    operation_index: int
    params: List[float] = field(default_factory=list)
    clbits: List[int] = field(default_factory=list)
    scheduled_time: Optional[int] = None
    duration: int = 1

    def __str__(self) -> str:
        param_str = f"({', '.join(f'{p:.3f}' for p in self.params)})" if self.params else ""
        time_str = f" @ t={self.scheduled_time}" if self.scheduled_time is not None else ""
        return f"LocalOp[{self.operation_index}]: {self.gate}{param_str} on QPU {self.qpu} qubits {self.logical_qubits}{time_str}"


@dataclass
class RemoteOperation:
    """
    Represents an inter-QPU remote quantum operation requiring network communication.
    """
    gate: str
    logical_control: int
    logical_target: int
    source_qpu: int
    destination_qpu: int
    operation_index: int
    logical_qubits: List[int] = field(default_factory=list)
    params: List[float] = field(default_factory=list)
    path: Optional[List[int]] = None
    cost: Optional[float] = None
    protocol_name: str = "telegate"
    bell_pairs_consumed: int = 0
    scheduled_time: Optional[int] = None
    duration: int = 1

    def __post_init__(self):
        if not self.logical_qubits:
            self.logical_qubits = [self.logical_control, self.logical_target]

    @property
    def protocol(self) -> RemoteGateProtocol:
        return PROTOCOLS.get(self.protocol_name.lower(), TeleGate())

    def compute_resource_requirements(self) -> None:
        """Compute Bell-pair and communication requirements for the assigned path."""
        if self.path and len(self.path) >= 2:
            self.bell_pairs_consumed = self.protocol.calculate_bell_pairs(self.path)
        else:
            self.bell_pairs_consumed = 0

    def __str__(self) -> str:
        path_str = f" via {self.path}" if self.path else ""
        time_str = f" @ t={self.scheduled_time}" if self.scheduled_time is not None else ""
        cost_str = f" (cost={self.cost:.2f})" if self.cost is not None else ""
        return (
            f"RemoteOp[{self.operation_index}]: {self.gate} "
            f"q{self.logical_control}(QPU{self.source_qpu}) -> q{self.logical_target}(QPU{self.destination_qpu})"
            f"{path_str}{time_str}{cost_str} [EPR={self.bell_pairs_consumed}]"
        )

