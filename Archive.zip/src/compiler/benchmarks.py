from qiskit import QuantumCircuit
import random


class Benchmarks:
    """
    Standard quantum benchmark circuits for DQC compilation testing.
    """

    def ghz(self, n: int) -> QuantumCircuit:
        """Create an n-qubit Greenberger-Horne-Zeilinger (GHZ) state circuit."""
        qc = QuantumCircuit(n, name=f"GHZ_{n}")
        qc.h(0)
        for i in range(n - 1):
            qc.cx(i, i + 1)
        return qc

    def qft(self, n: int) -> QuantumCircuit:
        """Create an n-qubit Quantum Fourier Transform (QFT) circuit."""
        try:
            from qiskit.circuit.library import qft as qft_func
            return qft_func(num_qubits=n)
        except (ImportError, TypeError):
            from qiskit.circuit.library import QFT
            return QFT(n)

    def random(self, n: int, depth: int = 20, seed: int = 42) -> QuantumCircuit:
        """Create an n-qubit pseudo-random circuit with two-qubit CX gates."""
        rng = random.Random(seed)
        qc = QuantumCircuit(n, name=f"Random_{n}_d{depth}")
        for _ in range(depth):
            a = rng.randint(0, n - 1)
            b = rng.randint(0, n - 1)
            while a == b:
                b = rng.randint(0, n - 1)
            qc.cx(a, b)
        return qc

    def hardware_efficient(self, n: int, reps: int = 2) -> QuantumCircuit:
        """Create an n-qubit hardware-efficient ansatz circuit."""
        try:
            from qiskit.circuit.library import efficient_su2
            return efficient_su2(num_qubits=n, reps=reps)
        except (ImportError, TypeError):
            try:
                from qiskit.circuit.library import EfficientSU2
                return EfficientSU2(n, reps=reps)
            except Exception:
                # Custom fallback
                qc = QuantumCircuit(n, name="EfficientSU2")
                for r in range(reps + 1):
                    for i in range(n):
                        qc.ry(0.5, i)
                        qc.rz(0.5, i)
                    if r < reps:
                        for i in range(n - 1):
                            qc.cx(i, i + 1)
                return qc