from typing import Dict, List, Optional
import networkx as nx


class KLPartitioner:
    """
    Generalized Kernighan-Lin Partitioner supporting 2-way and recursive N-way partitioning
    for multi-QPU systems with capacity and balance constraints.
    """

    def __init__(self, max_iter: int = 50, seed: Optional[int] = 42):
        """
        `seed` controls the RNG used internally by networkx's Kernighan-Lin
        bisection (initial partition shuffling / tie-breaking). It defaults to
        a fixed value so that partitioning -- and therefore the whole
        experiment -- is reproducible; pass seed=None to restore
        non-deterministic behavior.
        """
        self.max_iter = max_iter
        self.seed = seed

    def partition(
        self,
        graph: nx.Graph,
        num_qpus: int = 2,
        capacities: Optional[Dict[int, int]] = None
    ) -> Dict[int, List[int]]:
        """
        Partition graph nodes across num_qpus using Kernighan-Lin bisection (or recursive KL for N > 2).
        Returns a dict mapping {qpu_id: [list of logical qubits]}.
        """
        nodes = sorted(list(graph.nodes()))
        if not nodes:
            return {i: [] for i in range(num_qpus)}

        if num_qpus == 1:
            return {0: nodes}

        # If exactly 2 QPUs and no special capacity asymmetry, perform direct KL bisection
        if num_qpus == 2:
            return self._bisection(graph, nodes, capacities)

        # For N > 2, use recursive bisection / hierarchical KL
        return self._recursive_kl(graph, nodes, num_qpus, capacities)

    def _bisection(
        self,
        graph: nx.Graph,
        nodes: List[int],
        capacities: Optional[Dict[int, int]] = None
    ) -> Dict[int, List[int]]:
        """Perform 2-way Kernighan-Lin bisection on given nodes."""
        if len(nodes) <= 1:
            return {0: nodes, 1: []}

        # Ensure subgraph has edge weights
        subgraph = graph.subgraph(nodes).copy()
        for u in nodes:
            if not subgraph.has_node(u):
                subgraph.add_node(u)

        # If subgraph has no edges or is disconnected, ensure a valid bisection
        for u in nodes:
            for v in nodes:
                if u < v and not subgraph.has_edge(u, v):
                    subgraph.add_edge(u, v, weight=0.0)

        try:
            left, right = nx.community.kernighan_lin_bisection(
                subgraph,
                weight="weight",
                max_iter=self.max_iter,
                seed=self.seed
            )
            part_0 = sorted(list(left))
            part_1 = sorted(list(right))
        except Exception:
            # Fallback to balanced split
            mid = (len(nodes) + 1) // 2
            part_0 = nodes[:mid]
            part_1 = nodes[mid:]

        # Adjust for capacity constraints if provided
        if capacities is not None:
            c0 = capacities.get(0, len(nodes))
            c1 = capacities.get(1, len(nodes))

            while len(part_0) > c0 and len(part_1) < c1:
                # Move lowest interaction node from 0 to 1
                moved = part_0.pop()
                part_1.append(moved)
            while len(part_1) > c1 and len(part_0) < c0:
                moved = part_1.pop()
                part_0.append(moved)

        return {
            0: sorted(part_0),
            1: sorted(part_1)
        }

    def _recursive_kl(
        self,
        graph: nx.Graph,
        nodes: List[int],
        num_qpus: int,
        capacities: Optional[Dict[int, int]] = None
    ) -> Dict[int, List[int]]:
        """Recursively bisect to partition nodes into num_qpus partitions."""
        partitions: Dict[int, List[int]] = {i: [] for i in range(num_qpus)}

        # Queue of (current_nodes, list_of_qpu_target_indices)
        queue = [(nodes, list(range(num_qpus)))]

        while queue:
            current_nodes, qpu_targets = queue.pop(0)
            k = len(qpu_targets)

            if k == 1:
                partitions[qpu_targets[0]] = sorted(current_nodes)
                continue

            if not current_nodes:
                continue

            # Split qpu_targets into two halves
            mid = k // 2
            left_qpus = qpu_targets[:mid]
            right_qpus = qpu_targets[mid:]

            # Bisect current nodes
            two_way = self._bisection(graph, current_nodes)
            left_nodes = two_way[0]
            right_nodes = two_way[1]

            # Balance node counts proportionally to QPU counts
            target_left_count = int(round(len(current_nodes) * (len(left_qpus) / k)))
            while len(left_nodes) > target_left_count and len(right_nodes) < len(current_nodes):
                right_nodes.append(left_nodes.pop())
            while len(left_nodes) < target_left_count and len(right_nodes) > 0:
                left_nodes.append(right_nodes.pop())

            queue.append((left_nodes, left_qpus))
            queue.append((right_nodes, right_qpus))

        return partitions

    @staticmethod
    def to_qubit_map(partitions: Dict[int, List[int]]) -> Dict[int, int]:
        """Convert {qpu: [qubits]} to {qubit: qpu}."""
        mapping = {}
        for qpu, qubits in partitions.items():
            for q in qubits:
                mapping[q] = qpu
        return mapping