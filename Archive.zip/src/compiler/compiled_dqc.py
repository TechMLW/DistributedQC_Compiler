from typing import Dict, List, Tuple, Any, Optional
from qiskit import QuantumCircuit
from compiler.remote_ops import RemoteOperation, LocalOperation


class CompiledDQC:
    """
    Represents the complete compiled Distributed Quantum Computing output.
    
    Attributes:
        qpu_circuits: Dict[qpu_id, QuantumCircuit] containing the local executable circuits for each QPU.
        logical_to_qpu: Dict[logical_qubit_id, qpu_id].
        logical_to_physical: Dict[logical_qubit_id, (qpu_id, physical_qubit_id)].
        remote_operations: List of RemoteOperation objects.
        local_operations: List of LocalOperation objects.
        routes: Dict mapping operation_index -> list of QPU IDs [qpu_source, ..., qpu_dest].
        schedule: Dict containing operation timeline and makespan.
        network_statistics: Snapshot of network state (utilization, congestion, latency).
        resource_statistics: Detailed Bell-pair consumption metrics.
    """

    def __init__(
        self,
        qpu_circuits: Dict[int, QuantumCircuit],
        logical_to_qpu: Dict[int, int],
        logical_to_physical: Dict[int, Tuple[int, int]],
        remote_operations: List[RemoteOperation],
        local_operations: List[LocalOperation],
        routes: Dict[int, List[int]],
        schedule: Dict[str, Any],
        network_statistics: Dict[str, Any],
        resource_statistics: Dict[str, Any],
        original_circuit: Optional[QuantumCircuit] = None
    ):
        self.qpu_circuits = qpu_circuits
        self.logical_to_qpu = logical_to_qpu
        self.logical_to_physical = logical_to_physical
        self.remote_operations = remote_operations
        self.local_operations = local_operations
        self.routes = routes
        self.schedule = schedule
        self.network_statistics = network_statistics
        self.resource_statistics = resource_statistics
        self.original_circuit = original_circuit

    def get_qpu_circuit(self, qpu_id: int) -> Optional[QuantumCircuit]:
        """Retrieve the local QuantumCircuit for a specific QPU."""
        return self.qpu_circuits.get(qpu_id)

    def summary(self) -> str:
        """Return a formatted string summary of the compiled DQC artifact."""
        lines = [
            "==================================================",
            "        DISTRIBUTED QUANTUM COMPUTING (DQC)       ",
            "             COMPILED CIRCUIT ARTIFACT            ",
            "==================================================",
            f"Total QPUs: {len(self.qpu_circuits)}",
            f"Total Local Operations: {len(self.local_operations)}",
            f"Total Remote Operations: {len(self.remote_operations)}",
            f"Makespan (Time Steps): {self.resource_statistics.get('makespan', 'N/A')}",
            f"Total Bell Pairs Consumed: {self.resource_statistics.get('total_consumed_bell_pairs', 0)}",
            f"Total Bell Pairs Remaining: {self.resource_statistics.get('total_remaining_bell_pairs', 0)}",
            "",
            "--- Logical to Physical Mapping ---"
        ]
        for l_q, (qpu, p_q) in sorted(self.logical_to_physical.items()):
            lines.append(f"  Logical Qubit {l_q} -> QPU {qpu}, Physical Qubit {p_q}")

        lines.append("\n--- Per-QPU Local Circuits ---")
        for qpu_id, qc in self.qpu_circuits.items():
            lines.append(f"  QPU {qpu_id} Circuit: {qc.num_qubits} physical qubits, depth={qc.depth()}, ops={dict(qc.count_ops())}")

        if self.remote_operations:
            lines.append("\n--- Scheduled Remote Operations ---")
            for op in sorted(self.remote_operations, key=lambda x: (x.scheduled_time if x.scheduled_time is not None else -1, x.operation_index)):
                lines.append(f"  {op}")

        lines.append("==================================================")
        return "\n".join(lines)

    def print_summary(self) -> None:
        """Print summary to console."""
        print(self.summary())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize compiled representation into a dictionary."""
        return {
            "num_qpus": len(self.qpu_circuits),
            "logical_to_qpu": self.logical_to_qpu,
            "logical_to_physical": {k: list(v) for k, v in self.logical_to_physical.items()},
            "num_local_ops": len(self.local_operations),
            "num_remote_ops": len(self.remote_operations),
            "routes": self.routes,
            "resource_statistics": self.resource_statistics,
            "network_statistics": self.network_statistics
        }

