from typing import Dict, List, Optional
import networkx as nx


class Partitioner:
    """
    Greedy edge-weight partitioner that assigns high-interaction qubits to the same QPU
    while respecting heterogeneous QPU capacities and partition balance.
    """

    def partition(
        self,
        graph: nx.Graph,
        num_qpus: int,
        capacities: Optional[Dict[int, int]] = None
    ) -> Dict[int, List[int]]:
        """
        Partition graph nodes into num_qpus partitions respecting capacities.
        """
        if capacities is None:
            # Equal capacity split by default
            max_size = (len(graph.nodes()) + num_qpus - 1) // num_qpus
            qpu_capacities = {i: max_size for i in range(num_qpus)}
        else:
            qpu_capacities = dict(capacities)

        edges = sorted(
            graph.edges(data=True),
            key=lambda x: x[2].get("weight", 1),
            reverse=True
        )

        partitions: Dict[int, List[int]] = {i: [] for i in range(num_qpus)}
        assigned: Dict[int, int] = {}
        current_qpu = 0

        for u, v, data in edges:
            if u not in assigned and v not in assigned:
                # Try to place both on the current QPU if capacity allows
                target_qpu = current_qpu
                # Find a QPU that can fit both
                found = False
                for offset in range(num_qpus):
                    cand = (current_qpu + offset) % num_qpus
                    if len(partitions[cand]) + 2 <= qpu_capacities[cand]:
                        target_qpu = cand
                        found = True
                        break
                if not found:
                    # Find a QPU with at least 1 slot
                    for cand in range(num_qpus):
                        if len(partitions[cand]) < qpu_capacities[cand]:
                            target_qpu = cand
                            break

                if len(partitions[target_qpu]) < qpu_capacities[target_qpu]:
                    partitions[target_qpu].append(u)
                    assigned[u] = target_qpu
                if len(partitions[target_qpu]) < qpu_capacities[target_qpu]:
                    partitions[target_qpu].append(v)
                    assigned[v] = target_qpu

                current_qpu = (target_qpu + 1) % num_qpus

            elif u in assigned and v not in assigned:
                qpu = assigned[u]
                if len(partitions[qpu]) < qpu_capacities[qpu]:
                    partitions[qpu].append(v)
                    assigned[v] = qpu

            elif v in assigned and u not in assigned:
                qpu = assigned[v]
                if len(partitions[qpu]) < qpu_capacities[qpu]:
                    partitions[qpu].append(u)
                    assigned[u] = qpu

        # Assign remaining/isolated qubits to QPU with most remaining capacity
        for node in sorted(graph.nodes()):
            if node not in assigned:
                # Find QPU with most available capacity
                available_qpus = [
                    q for q in range(num_qpus)
                    if len(partitions[q]) < qpu_capacities[q]
                ]
                if available_qpus:
                    chosen = min(available_qpus, key=lambda q: len(partitions[q]))
                else:
                    chosen = min(partitions.keys(), key=lambda q: len(partitions[q]))

                partitions[chosen].append(node)
                assigned[node] = chosen

        # Sort and clean
        for qpu in partitions:
            partitions[qpu] = sorted(list(set(partitions[qpu])))

        return partitions

    @staticmethod
    def to_qubit_map(partitions: Dict[int, List[int]]) -> Dict[int, int]:
        """Convert {qpu: [qubits]} to {qubit: qpu}."""
        mapping = {}
        for qpu, qubits in partitions.items():
            for q in qubits:
                mapping[q] = qpu
        return mapping