from dataclasses import dataclass
from typing import Optional, Dict, Any
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, Operator, state_fidelity, process_fidelity

from compiler.compiled_dqc import CompiledDQC
from compiler.remote_ops import LocalOperation, RemoteOperation


@dataclass
class ValidationResult:
    """
    Result of semantic equivalence validation between original and compiled distributed circuits.
    """
    is_valid: bool
    fidelity: float
    unitary_fidelity: Optional[float] = None
    details: str = ""

    def __str__(self) -> str:
        status = "PASSED" if self.is_valid else "FAILED"
        u_fid_str = f", Unitary Fidelity={self.unitary_fidelity:.6f}" if self.unitary_fidelity is not None else ""
        return f"Validation [{status}]: State Fidelity = {self.fidelity:.6f}{u_fid_str}\nDetails: {self.details}"


class SemanticValidator:
    """
    Validates semantic equivalence of a CompiledDQC program against the original QuantumCircuit
    using statevector and unitary operator simulations.
    """

    def __init__(self, tolerance: float = 1e-5):
        self.tolerance = tolerance

    def validate(
        self,
        original_circuit: QuantumCircuit,
        compiled_dqc: CompiledDQC
    ) -> ValidationResult:
        """
        Verify that the compiled distributed representation preserves the exact quantum state evolution
        of the original monolithic circuit.
        """
        num_qubits = original_circuit.num_qubits

        # 1. Compute ideal Statevector of original circuit
        try:
            sv_orig = Statevector.from_instruction(original_circuit)
        except Exception as e:
            # Fallback if circuit has custom instructions
            sv_orig = Statevector.from_label("0" * num_qubits).evolve(original_circuit)

        # 2. Reconstruct global circuit from scheduled DQC execution plan
        reconstructed_qc = QuantumCircuit(num_qubits)

        # Combine all scheduled operations and sort by scheduled time and original operation index
        all_ops = list(compiled_dqc.local_operations) + list(compiled_dqc.remote_operations)
        all_ops.sort(key=lambda op: (op.scheduled_time if op.scheduled_time is not None else -1, op.operation_index))

        for op in all_ops:
            if isinstance(op, LocalOperation):
                self._apply_gate(reconstructed_qc, op.gate, op.logical_qubits, op.params)
            elif isinstance(op, RemoteOperation):
                # Remote gate execution on control and target logical qubits
                self._apply_gate(reconstructed_qc, op.gate, [op.logical_control, op.logical_target], op.params)

        # 3. Compute Statevector of reconstructed DQC execution
        sv_dqc = Statevector.from_instruction(reconstructed_qc)

        # 4. Compute State Fidelity: |<psi_orig | psi_dqc>|^2
        fid = float(state_fidelity(sv_orig, sv_dqc))

        # 5. Unitary operator fidelity for small circuits (<= 10 qubits)
        u_fid = None
        if num_qubits <= 10:
            try:
                op_orig = Operator(original_circuit)
                op_dqc = Operator(reconstructed_qc)
                u_fid = float(process_fidelity(op_orig, op_dqc))
            except Exception:
                pass

        is_valid = (1.0 - fid) <= self.tolerance

        details = (
            f"Validated {len(all_ops)} total operations ({len(compiled_dqc.local_operations)} local, "
            f"{len(compiled_dqc.remote_operations)} remote) across {len(compiled_dqc.qpu_circuits)} QPUs."
        )

        return ValidationResult(
            is_valid=is_valid,
            fidelity=fid,
            unitary_fidelity=u_fid,
            details=details
        )
    
    def _apply_gate(
        self,
        qc: QuantumCircuit,
        gate_name: str,
        qubits: list,
        params: list
    ) -> None:
        """Apply gate by name to reconstructed circuit."""
        name = gate_name.lower()
        if name == "h":
            qc.h(qubits[0])
        elif name == "x":
            qc.x(qubits[0])
        elif name == "y":
            qc.y(qubits[0])
        elif name == "z":
            qc.z(qubits[0])
        elif name == "s":
            qc.s(qubits[0])
        elif name == "sdg":
            qc.sdg(qubits[0])
        elif name == "t":
            qc.t(qubits[0])
        elif name == "tdg":
            qc.tdg(qubits[0])
        elif name == "rx":
            qc.rx(params[0] if params else 0.0, qubits[0])
        elif name == "ry":
            qc.ry(params[0] if params else 0.0, qubits[0])
        elif name == "rz":
            qc.rz(params[0] if params else 0.0, qubits[0])
        elif name == "p":
            qc.p(params[0] if params else 0.0, qubits[0])
        elif name == "cx" or name == "cnot":
            qc.cx(qubits[0], qubits[1])
        elif name == "cz":
            qc.cz(qubits[0], qubits[1])
        elif name == "swap":
            qc.swap(qubits[0], qubits[1])
        elif name == "barrier":
            qc.barrier(qubits)
        else:
            if hasattr(qc, name):
                getattr(qc, name)(*qubits)

