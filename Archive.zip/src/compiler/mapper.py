from typing import Dict, List, Tuple, Optional
import networkx as nx
from network.topology import Topology


class PhysicalMapper:
    """
    Maps logical qubits assigned to each QPU to concrete physical qubits
    on that QPU's physical coupling graph.
    
    Produces:
        - logical_to_qpu: {logical_qubit: qpu_id}
        - logical_to_physical: {logical_qubit: (qpu_id, physical_qubit_id)}
        - qpu_mappings: {qpu_id: {logical_qubit: physical_qubit_id}}
    """

    def map_qubits(
        self,
        partitions: Dict[int, List[int]],
        topology: Topology,
        interaction_graph: Optional[nx.Graph] = None
    ) -> Tuple[Dict[int, int], Dict[int, Tuple[int, int]]]:
        """
        Compute logical-to-QPU and logical-to-physical qubit mappings.
        """
        logical_to_qpu: Dict[int, int] = {}
        logical_to_physical: Dict[int, Tuple[int, int]] = {}

        for qpu_id, logical_qubits in partitions.items():
            if qpu_id not in topology.qpus:
                continue

            qpu = topology.qpus[qpu_id]
            coupling = qpu.coupling_graph
            available_physical = sorted(list(coupling.nodes()))

            # If interaction graph is provided, place interacting pairs on coupled physical nodes
            local_mapping = self._place_on_coupling_graph(
                logical_qubits=logical_qubits,
                coupling_graph=coupling,
                interaction_graph=interaction_graph
            )

            # Store mapping in QPU
            qpu.set_physical_mapping(local_mapping)

            for l_q, p_q in local_mapping.items():
                logical_to_qpu[l_q] = qpu_id
                logical_to_physical[l_q] = (qpu_id, p_q)

        return logical_to_qpu, logical_to_physical

    def _place_on_coupling_graph(
        self,
        logical_qubits: List[int],
        coupling_graph: nx.Graph,
        interaction_graph: Optional[nx.Graph] = None
    ) -> Dict[int, int]:
        """
        Place logical qubits onto physical qubits on the coupling graph,
        prioritizing adjacent physical qubits for interacting logical qubits.
        """
        mapping: Dict[int, int] = {}
        available_physical = set(coupling_graph.nodes())

        if not logical_qubits:
            return mapping

        if interaction_graph is None or len(logical_qubits) == 1:
            # Trivial 1-to-1 sequential mapping
            for l_q, p_q in zip(logical_qubits, sorted(list(available_physical))):
                mapping[l_q] = p_q
            return mapping

        # Subgraph of interaction for local qubits
        local_subgraph = interaction_graph.subgraph(logical_qubits)
        
        # Sort logical qubits by local degree (interaction weight)
        sorted_logical = sorted(
            logical_qubits,
            key=lambda q: sum(d.get("weight", 1) for _, _, d in local_subgraph.edges(q, data=True)),
            reverse=True
        )

        for l_q in sorted_logical:
            if not available_physical:
                break

            # Find already placed neighbors
            placed_neighbors = [
                (nbr, mapping[nbr]) for nbr in local_subgraph.neighbors(l_q)
                if nbr in mapping
            ]

            if not placed_neighbors:
                # Place on physical node with highest degree in coupling graph
                best_p = max(
                    available_physical,
                    key=lambda p: coupling_graph.degree(p) if coupling_graph.has_node(p) else 0
                )
            else:
                # Place as close as possible to already mapped physical neighbors
                def distance_score(p_candidate):
                    dist_sum = 0
                    for _, p_nbr in placed_neighbors:
                        try:
                            dist = nx.shortest_path_length(coupling_graph, p_candidate, p_nbr)
                        except (nx.NetworkXNoPath, nx.NodeNotFound):
                            dist = 100
                        dist_sum += dist
                    return dist_sum

                best_p = min(available_physical, key=distance_score)

            mapping[l_q] = best_p
            available_physical.remove(best_p)

        return mapping

