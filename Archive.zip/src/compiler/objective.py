from typing import Dict, List, Optional, Any, Union


class ObjectiveFunction:
    """
    Evaluates partition quality balancing communication cost, load imbalance,
    and network health metrics (latency, fidelity, Bell pairs, congestion).
    """

    def __init__(
        self,
        monitor: Optional[Any] = None,
        alpha: float = 1.0,
        beta: float = 1.0,
        gamma: float = 1.0,
        delta: float = 1.0,
        epsilon: float = 1.0,
        zeta: float = 1.0
    ):
        self.monitor = monitor
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.epsilon = epsilon
        self.zeta = zeta

    def evaluate(
        self,
        communication_cost: float,
        partitions: Union[Dict[int, List[int]], Dict[int, int]]
    ) -> float:
        # Standardize partitions to {qpu: [qubits]}
        qpu_to_qubits: Dict[int, List[int]] = {}
        for k, v in partitions.items():
            if isinstance(v, (list, tuple, set)):
                qpu_to_qubits[k] = list(v)
            else:
                # k is qubit, v is qpu
                if v not in qpu_to_qubits:
                    qpu_to_qubits[v] = []
                qpu_to_qubits[v].append(k)

        # Load imbalance
        sizes = [len(v) for v in qpu_to_qubits.values()]
        imbalance = max(sizes) - min(sizes) if sizes else 0

        latency_cost = 0.0
        fidelity_cost = 0.0
        bellpair_cost = 0.0
        congestion_cost = 0.0

        if self.monitor is not None:
            qpus = list(qpu_to_qubits.keys())
            for i in range(len(qpus)):
                for j in range(i + 1, len(qpus)):
                    state = self.monitor.get_state(qpus[i], qpus[j])
                    if state is None:
                        continue

                    latency_cost += state["latency"]
                    fidelity_cost += (1.0 - state["fidelity"]) * 100.0
                    bellpair_cost += 20.0 / (state["bell_pairs"] + 1)
                    congestion_cost += state["congestion"]

        total = (
            self.alpha * communication_cost
            + self.beta * imbalance
            + self.gamma * latency_cost
            + self.delta * fidelity_cost
            + self.epsilon * bellpair_cost
            + self.zeta * congestion_cost
        )

        return total