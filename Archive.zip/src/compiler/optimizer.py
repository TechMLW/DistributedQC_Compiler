from copy import deepcopy
from typing import Dict, List, Tuple, Optional, Any, Union
import networkx as nx
from compiler.communication_cost import CommunicationCost
from compiler.objective import ObjectiveFunction


class OptimizationResult:
    """
    Encapsulates the result of an adaptive optimization step.
    Supports unpacking as (partition, score) for 100% backward compatibility.
    """
    def __init__(
        self,
        partition: Dict[int, List[int]],
        score: float,
        changed: bool,
        changed_qubits: List[int],
        old_score: float,
        old_cost: float,
        new_cost: float,
        reason: str
    ):
        self.partition = partition
        self.score = score
        self.changed = changed
        self.changed_qubits = changed_qubits
        self.old_score = old_score
        self.old_cost = old_cost
        self.new_cost = new_cost
        self.reason = reason

    def __iter__(self):
        # Enables unpacking as: partition, score = optimizer.adaptive_optimize(...)
        yield self.partition
        yield self.score

    def __getitem__(self, index):
        if index == 0:
            return self.partition
        elif index == 1:
            return self.score
        elif index == 2:
            return self.changed
        elif index == 3:
            return self.changed_qubits
        raise IndexError("Index out of range for OptimizationResult")

    def __len__(self):
        return 4


class Optimizer:
    """
    Optimizes qubit partition assignments across QPUs to minimize communication overhead
    and balance load using local search / Kernighan-Lin-style neighborhood swaps.
    """

    def __init__(self, monitor: Optional[Any] = None):
        self.monitor = monitor
        self.cost = CommunicationCost(monitor)
        self.objective = ObjectiveFunction(monitor)

    @staticmethod
    def is_partition_changed(
        p1: Union[Dict[int, List[int]], Dict[int, int]],
        p2: Union[Dict[int, List[int]], Dict[int, int]]
    ) -> Tuple[bool, List[int]]:
        """
        Compare actual logical-qubit -> QPU assignments between two partitions.
        Returns (changed: bool, list_of_changed_qubits: List[int]).
        """
        def to_map(p):
            m = {}
            for k, v in p.items():
                if isinstance(v, (list, tuple, set)):
                    for q in v:
                        m[q] = k
                else:
                    m[k] = v
            return m

        m1 = to_map(p1)
        m2 = to_map(p2)

        all_qubits = sorted(list(set(m1.keys()) | set(m2.keys())))
        changed_qubits = []

        for q in all_qubits:
            if m1.get(q) != m2.get(q):
                changed_qubits.append(q)

        return len(changed_qubits) > 0, changed_qubits

    def optimize(
        self,
        graph: nx.Graph,
        initial_partition: Dict[int, List[int]],
        topology: Optional[Any] = None,
        capacities: Optional[Dict[int, int]] = None
    ) -> Tuple[Dict[int, List[int]], float]:
        """
        Perform local swap search under current network state to find partition with minimal objective score.
        """
        best_partition = deepcopy(initial_partition)
        # Ensure initial partition is sorted
        for qpu in best_partition:
            best_partition[qpu] = sorted(best_partition[qpu])

        best_cost = self.cost.calculate(graph, best_partition, topology=topology)
        best_score = self.objective.evaluate(best_cost, best_partition)

        improved = True
        iterations = 0
        max_iterations = 30

        while improved and iterations < max_iterations:
            improved = False
            iterations += 1
            qpus = list(best_partition.keys())

            for i in range(len(qpus)):
                for j in range(i + 1, len(qpus)):
                    q1, q2 = qpus[i], qpus[j]

                    for a in list(best_partition[q1]):
                        for b in list(best_partition[q2]):
                            candidate = deepcopy(best_partition)

                            if a not in candidate[q1] or b not in candidate[q2]:
                                continue

                            # Swap qubits a and b
                            candidate[q1].remove(a)
                            candidate[q2].remove(b)
                            candidate[q1].append(b)
                            candidate[q2].append(a)

                            # Capacity check
                            if capacities:
                                if len(candidate[q1]) > capacities.get(q1, 100) or len(candidate[q2]) > capacities.get(q2, 100):
                                    continue

                            cand_cost = self.cost.calculate(graph, candidate, topology=topology)
                            cand_score = self.objective.evaluate(cand_cost, candidate)

                            if cand_score < best_score - 1e-4:
                                best_score = cand_score
                                best_partition = candidate
                                improved = True

        for qpu in best_partition:
            best_partition[qpu] = sorted(best_partition[qpu])

        return best_partition, best_score

    def adaptive_optimize(
        self,
        graph: nx.Graph,
        current_partition: Dict[int, List[int]],
        communication_cost: Optional[float] = None,
        threshold: float = 2.0,
        topology: Optional[Any] = None,
        capacities: Optional[Dict[int, int]] = None
    ) -> OptimizationResult:
        """
        Adaptively evaluate candidate partitions using the CURRENT network state.
        Determines whether an ACTUAL partition change is justified.
        """
        # Always compute current communication cost from CURRENT network state
        current_comm_cost = self.cost.calculate(graph, current_partition, topology=topology)
        current_score = self.objective.evaluate(current_comm_cost, current_partition)

        candidate_partition, candidate_score = self.optimize(
            graph,
            current_partition,
            topology=topology,
            capacities=capacities
        )

        changed, changed_qubits = self.is_partition_changed(current_partition, candidate_partition)
        candidate_comm_cost = self.cost.calculate(graph, candidate_partition, topology=topology)

        if changed and candidate_score < current_score - threshold:
            reason = f"Candidate score ({candidate_score:.3f}) improved by >= threshold ({threshold:.3f}) over current ({current_score:.3f})"
            return OptimizationResult(
                partition=candidate_partition,
                score=candidate_score,
                changed=True,
                changed_qubits=changed_qubits,
                old_score=current_score,
                old_cost=current_comm_cost,
                new_cost=candidate_comm_cost,
                reason=reason
            )
        else:
            if not changed:
                reason = "No alternative partition found with lower objective score"
            else:
                reason = f"Candidate score improvement ({current_score - candidate_score:.3f}) below threshold ({threshold:.3f})"

            return OptimizationResult(
                partition=current_partition,
                score=current_score,
                changed=False,
                changed_qubits=[],
                old_score=current_score,
                old_cost=current_comm_cost,
                new_cost=current_comm_cost,
                reason=reason
            )