import random
import statistics
import unittest
from network.link import Link
from network.monitor import NetworkMonitor
from network.topology import Topology


class TestCongestionModel(unittest.TestCase):

    def test_link_demand_and_utilization(self):
        # Capacity = 10, Demand = 5 -> rho = 0.5, Congestion = 50%
        link = Link(source=0, destination=1, capacity=10.0, demand=5.0)
        self.assertEqual(link.utilization, 0.5)
        self.assertEqual(link.congestion, 50.0)

        # Update demand to 12 -> utilization = 1.2, Congestion = 120% (overload stays visible, never clamped)
        link.update_demand(12.0)
        self.assertEqual(link.utilization, 1.2)
        self.assertEqual(link.congestion, 120.0)

    def test_monitor_route_recalculation(self):
        monitor = NetworkMonitor()
        monitor.register_link(0, 1, capacity=5.0)
        monitor.register_link(1, 2, capacity=10.0)

        # 3 routes traversing [0, 1, 2]
        routes = [[0, 1, 2], [0, 1, 2], [0, 1, 2]]
        monitor.recalculate_from_routes(routes)

        state_01 = monitor.get_state(0, 1)
        state_12 = monitor.get_state(1, 2)

        self.assertEqual(state_01["demand"], 3.0)
        self.assertEqual(state_01["utilization"], 3.0 / 5.0)
        self.assertEqual(state_01["congestion"], 60.0)

        self.assertEqual(state_12["demand"], 3.0)
        self.assertEqual(state_12["utilization"], 3.0 / 10.0)
        self.assertEqual(state_12["congestion"], 30.0)

    def test_bell_pair_consumption(self):
        link = Link(source=0, destination=1, bell_pairs=10)
        success = link.consume_bell_pair(3)
        self.assertTrue(success)
        self.assertEqual(link.bell_pairs, 7)
        self.assertEqual(link.consumed_bell_pairs, 3)

        # Fail when consuming more than remaining
        fail = link.consume_bell_pair(8)
        self.assertFalse(fail)
        self.assertEqual(link.bell_pairs, 7)

    def test_network_evolution_is_mean_reverting_not_systematically_biased(self):
        """
        The generic environment model must not hide a scenario in its noise:
        latency should wander around its baseline over many steps, not drift
        monotonically in one direction (which would silently guarantee
        congestion/triggers regardless of the seed).
        """
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, latency=15.0, capacity=10.0, bell_pairs=50)
        monitor = NetworkMonitor(topology=topo, rng=random.Random(1))

        baseline_latency = topo.get_link(0, 1).latency
        samples = []
        for _ in range(200):
            monitor.update()
            samples.append(topo.get_link(0, 1).latency)

        # Mean-reverting around baseline: the long-run average should stay
        # close to the baseline rather than drifting far away from it.
        self.assertLess(abs(statistics.fmean(samples) - baseline_latency), 5.0)
        # And it must actually vary (a real random walk), not sit frozen.
        self.assertGreater(statistics.pstdev(samples), 0.5)


if __name__ == "__main__":
    unittest.main()

