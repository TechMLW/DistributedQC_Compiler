import unittest
import networkx as nx
from compiler.kl_partitioner import KLPartitioner
from compiler.partitioner import Partitioner


class TestPartitioners(unittest.TestCase):

    def setUp(self):
        # Build 6-qubit graph: cluster (0, 1, 2) and cluster (3, 4, 5) with weak link (2, 3)
        self.g = nx.Graph()
        self.g.add_edge(0, 1, weight=5)
        self.g.add_edge(1, 2, weight=5)
        self.g.add_edge(0, 2, weight=5)

        self.g.add_edge(3, 4, weight=5)
        self.g.add_edge(4, 5, weight=5)
        self.g.add_edge(3, 5, weight=5)

        self.g.add_edge(2, 3, weight=1)

    def test_2_way_kl_partitioning(self):
        kl = KLPartitioner()
        parts = kl.partition(self.g, num_qpus=2)
        self.assertEqual(len(parts), 2)
        self.assertEqual(len(parts[0]) + len(parts[1]), 6)
        # Verify cluster separation
        self.assertTrue(set(parts[0]) == {0, 1, 2} or set(parts[0]) == {3, 4, 5})

    def test_multi_qpu_kl_partitioning(self):
        kl = KLPartitioner()
        # 8 qubits across 4 QPUs
        g8 = nx.path_graph(8)
        parts = kl.partition(g8, num_qpus=4)
        self.assertEqual(len(parts), 4)
        all_nodes = [q for q_list in parts.values() for q in q_list]
        self.assertEqual(sorted(all_nodes), list(range(8)))

    def test_greedy_partitioner_capacity(self):
        greedy = Partitioner()
        caps = {0: 3, 1: 3}
        parts = greedy.partition(self.g, num_qpus=2, capacities=caps)
        self.assertEqual(len(parts[0]), 3)
        self.assertEqual(len(parts[1]), 3)

    def test_isolated_qubit_handling(self):
        g_iso = nx.Graph()
        g_iso.add_nodes_from([0, 1, 2, 3])
        g_iso.add_edge(0, 1, weight=2)
        # Qubits 2 and 3 are isolated
        kl = KLPartitioner()
        parts = kl.partition(g_iso, num_qpus=2)
        all_nodes = sorted([q for q_list in parts.values() for q in q_list])
        self.assertEqual(all_nodes, [0, 1, 2, 3])


if __name__ == "__main__":
    unittest.main()

