import unittest
from qiskit import QuantumCircuit
from network.topology import Topology
from compiler.compiler import DQCCompiler
from compiler.validator import SemanticValidator
from compiler.benchmarks import Benchmarks


class TestSemanticValidation(unittest.TestCase):

    def setUp(self):
        self.compiler = DQCCompiler()
        self.validator = SemanticValidator(tolerance=1e-5)
        self.bench = Benchmarks()

    def test_single_qubit_gates_equivalence(self):
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.x(1)
        qc.y(2)
        qc.z(3)
        qc.rx(0.4, 0)
        qc.ry(0.8, 1)

        compiled = self.compiler.compile(qc)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)

    def test_local_two_qubit_gates_equivalence(self):
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)
        qc.h(2)
        qc.cx(2, 3)

        compiled = self.compiler.compile(qc)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)

    def test_remote_two_qubit_gates_equivalence(self):
        # 2 QPUs (capacity 2 each): QPU 0 has [0, 1], QPU 1 has [2, 3]
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)  # local
        qc.cx(1, 2)  # remote
        qc.cx(2, 3)  # local
        qc.cx(0, 3)  # remote

        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, bell_pairs=20)
        compiled = self.compiler.compile(qc, topology=topo)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)

    def test_multi_hop_distributed_equivalence(self):
        # 3 QPUs in line: 0 <--> 1 <--> 2
        # QPU 0: [0], QPU 1: [1], QPU 2: [2]
        qc = QuantumCircuit(3)
        qc.h(0)
        qc.cx(0, 1)  # 1 hop
        qc.cx(1, 2)  # 1 hop
        qc.cx(0, 2)  # 2 hops (multi-hop [0, 1, 2])
        qc.h(2)

        topo = Topology.create_line_topology(num_qpus=3, qpu_capacity=1, bell_pairs=20)
        compiled = self.compiler.compile(qc, topology=topo)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)

    def test_ghz_benchmark_equivalence(self):
        qc = self.bench.ghz(6)
        topo = Topology.create_line_topology(num_qpus=3, qpu_capacity=2, bell_pairs=50)

        compiled = self.compiler.compile(qc, topology=topo)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)

    def test_4_qpu_mesh_network_equivalence(self):
        qc = QuantumCircuit(8)
        for i in range(8):
            qc.h(i)
        for i in range(7):
            qc.cx(i, i + 1)
        qc.cx(0, 7)

        topo = Topology.create_mesh_topology(num_qpus=4, qpu_capacity=2, bell_pairs=100)
        compiled = self.compiler.compile(qc, topology=topo)
        res = self.validator.validate(qc, compiled)

        self.assertTrue(res.is_valid)
        self.assertAlmostEqual(res.fidelity, 1.0, places=5)


if __name__ == "__main__":
    unittest.main()

