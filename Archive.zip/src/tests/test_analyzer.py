import unittest
from qiskit import QuantumCircuit
from compiler.analyzer import CircuitAnalyzer


class TestCircuitAnalyzer(unittest.TestCase):

    def setUp(self):
        self.analyzer = CircuitAnalyzer()

    def test_single_qubit_circuit(self):
        qc = QuantumCircuit(3)
        qc.h(0)
        qc.x(1)
        qc.z(2)
        res = self.analyzer.analyze(qc)
        self.assertEqual(res["qubits"], 3)
        self.assertEqual(res["gate_count"], 3)
        self.assertEqual(len(res["communication_gates"]), 0)

    def test_two_qubit_interactions(self):
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)
        qc.cx(0, 3)
        res = self.analyzer.analyze(qc)
        self.assertEqual(res["qubits"], 4)
        self.assertEqual(len(res["communication_gates"]), 4)
        self.assertEqual(len(res["two_qubit_gates"]), 4)
        self.assertEqual(res["operations"]["cx"], 4)
        self.assertEqual(res["operations"]["h"], 1)

    def test_parametric_gates(self):
        qc = QuantumCircuit(2)
        qc.rx(0.5, 0)
        qc.rz(1.2, 1)
        qc.cx(0, 1)
        res = self.analyzer.analyze(qc)
        self.assertEqual(res["gate_count"], 3)
        self.assertEqual(len(res["gate_sequence"]), 3)
        self.assertAlmostEqual(res["gate_sequence"][0]["params"][0], 0.5)


if __name__ == "__main__":
    unittest.main()

