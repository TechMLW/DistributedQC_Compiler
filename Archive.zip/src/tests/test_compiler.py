import unittest
from qiskit import QuantumCircuit
from network.topology import Topology
from compiler.compiler import DQCCompiler
from compiler.benchmarks import Benchmarks


class TestDQCCompiler(unittest.TestCase):

    def setUp(self):
        self.compiler = DQCCompiler()
        self.bench = Benchmarks()

    def test_compile_ghz_circuit(self):
        qc = self.bench.ghz(6)
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=4, bell_pairs=50)

        compiled = self.compiler.compile(qc, topology=topo)

        self.assertIsNotNone(compiled)
        self.assertEqual(len(compiled.qpu_circuits), 2)
        self.assertEqual(len(compiled.logical_to_qpu), 6)
        self.assertGreater(len(compiled.remote_operations), 0)
        self.assertGreater(len(compiled.local_operations), 0)
        self.assertIn("makespan", compiled.schedule)
        self.assertGreater(compiled.resource_statistics["total_consumed_bell_pairs"], 0)

    def test_compile_multi_hop_network(self):
        # 3 QPUs in a line: 0 <--> 1 <--> 2, capacity 1 each
        # Circuit with 3 qubits: 0 on QPU0, 1 on QPU1, 2 on QPU2
        qc = QuantumCircuit(3)
        qc.h(0)
        qc.cx(0, 1)  # QPU 0 <-> QPU 1
        qc.cx(1, 2)  # QPU 1 <-> QPU 2
        qc.cx(0, 2)  # QPU 0 <-> QPU 2 -> requires multi-hop path [0, 1, 2]

        topo = Topology.create_line_topology(num_qpus=3, qpu_capacity=1, bell_pairs=50)
        compiled = self.compiler.compile(qc, topology=topo)

        self.assertEqual(len(compiled.qpu_circuits), 3)
        self.assertGreaterEqual(len(compiled.remote_operations), 2)

        # Check that at least one operation traversed multi-hop path [0, 1, 2]
        multi_hop_ops = [op for op in compiled.remote_operations if len(op.path) > 2]
        self.assertGreaterEqual(len(multi_hop_ops), 1)
        self.assertEqual(multi_hop_ops[0].path, [0, 1, 2])

    def test_compile_hardware_efficient_benchmark(self):
        qc = self.bench.hardware_efficient(4)
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=3, bell_pairs=50)

        compiled = self.compiler.compile(qc, topology=topo)
        self.assertEqual(len(compiled.qpu_circuits), 2)
        self.assertEqual(len(compiled.logical_to_physical), 4)

    def test_summary_and_serialization(self):
        qc = self.bench.ghz(4)
        compiled = self.compiler.compile(qc)

        summary = compiled.summary()
        self.assertIn("DISTRIBUTED QUANTUM COMPUTING", summary)

        d = compiled.to_dict()
        self.assertEqual(d["num_qpus"], 2)
        self.assertIn("resource_statistics", d)


if __name__ == "__main__":
    unittest.main()

