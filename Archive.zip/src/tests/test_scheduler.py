import unittest
from network.topology import Topology
from compiler.remote_ops import LocalOperation, RemoteOperation
from compiler.scheduler import RemoteOperationScheduler, SchedulingError


class TestScheduler(unittest.TestCase):

    def setUp(self):
        # 3 QPUs: 0 <--> 1 <--> 2
        self.topo = Topology.create_line_topology(num_qpus=3, bell_pairs=10)
        self.scheduler = RemoteOperationScheduler()

    def test_local_and_remote_scheduling(self):
        op1 = LocalOperation(gate="h", logical_qubits=[0], qpu=0, operation_index=0)
        op2 = RemoteOperation(
            gate="cx", logical_control=0, logical_target=2, source_qpu=0, destination_qpu=1,
            operation_index=1, path=[0, 1]
        )
        op3 = LocalOperation(gate="x", logical_qubits=[0], qpu=0, operation_index=2)

        scheduled_ops, makespan, stats = self.scheduler.schedule([op1, op2, op3], self.topo)

        self.assertEqual(len(scheduled_ops), 3)
        self.assertEqual(op2.scheduled_time, 1)  # Starts after op1 on qubit 0 finishes
        self.assertGreaterEqual(makespan, 2)
        self.assertEqual(stats["total_consumed_bell_pairs"], 1)

    def test_link_conflict_serialization(self):
        # Two independent remote operations that share link (0, 1) with capacity = 1
        topo = Topology()
        topo.add_qpu(0, 4)
        topo.add_qpu(1, 4)
        topo.connect(0, 1, capacity=1.0, bell_pairs=10)

        op1 = RemoteOperation(
            gate="cx", logical_control=0, logical_target=1, source_qpu=0, destination_qpu=1,
            operation_index=0, path=[0, 1]
        )
        op2 = RemoteOperation(
            gate="cx", logical_control=2, logical_target=3, source_qpu=0, destination_qpu=1,
            operation_index=1, path=[0, 1]
        )

        scheduled_ops, makespan, _ = self.scheduler.schedule([op1, op2], topo)

        # Since link capacity is 1, op2 must be serialized after op1 finishes
        self.assertEqual(op1.scheduled_time, 0)
        self.assertGreaterEqual(op2.scheduled_time, op1.scheduled_time + op1.duration)

    def test_bell_pair_exhaustion_error(self):
        topo = Topology()
        topo.add_qpu(0, 4)
        topo.add_qpu(1, 4)
        topo.connect(0, 1, capacity=1.0, bell_pairs=1)  # Only 1 Bell pair

        op1 = RemoteOperation(
            gate="cx", logical_control=0, logical_target=1, source_qpu=0, destination_qpu=1,
            operation_index=0, path=[0, 1]
        )
        op2 = RemoteOperation(
            gate="cx", logical_control=0, logical_target=1, source_qpu=0, destination_qpu=1,
            operation_index=1, path=[0, 1]
        )

        with self.assertRaises(SchedulingError):
            self.scheduler.schedule([op1, op2], topo)


if __name__ == "__main__":
    unittest.main()

