import unittest
import networkx as nx
from network.topology import Topology
from compiler.mapper import PhysicalMapper


class TestPhysicalMapper(unittest.TestCase):

    def setUp(self):
        self.topo = Topology()
        self.topo.add_qpu(0, capacity=4, topology_type="line")
        self.topo.add_qpu(1, capacity=4, topology_type="grid")
        self.mapper = PhysicalMapper()

    def test_logical_to_physical_mapping(self):
        partitions = {
            0: [0, 1, 2],
            1: [3, 4, 5]
        }
        l_to_qpu, l_to_phys = self.mapper.map_qubits(partitions, self.topo)

        self.assertEqual(len(l_to_qpu), 6)
        self.assertEqual(len(l_to_phys), 6)

        for q in [0, 1, 2]:
            self.assertEqual(l_to_qpu[q], 0)
            self.assertEqual(l_to_phys[q][0], 0)
            self.assertIn(l_to_phys[q][1], [0, 1, 2, 3])

        for q in [3, 4, 5]:
            self.assertEqual(l_to_qpu[q], 1)
            self.assertEqual(l_to_phys[q][0], 1)
            self.assertIn(l_to_phys[q][1], [0, 1, 2, 3])

    def test_interaction_aware_placement(self):
        # Interacting logical qubits (0, 1) should be placed adjacently on line QPU
        interaction = nx.Graph()
        interaction.add_edge(0, 1, weight=10)
        interaction.add_edge(1, 2, weight=1)

        partitions = {0: [0, 1, 2]}
        l_to_qpu, l_to_phys = self.mapper.map_qubits(partitions, self.topo, interaction_graph=interaction)

        p0 = l_to_phys[0][1]
        p1 = l_to_phys[1][1]
        # Check that physical qubits p0 and p1 are adjacent on the line topology (|p0 - p1| == 1)
        self.assertEqual(abs(p0 - p1), 1)


if __name__ == "__main__":
    unittest.main()

