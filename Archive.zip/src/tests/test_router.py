import unittest
import networkx as nx
from network.topology import Topology
from compiler.router import ShortestPathRouter


class TestRouter(unittest.TestCase):

    def setUp(self):
        # 4-QPU Line Topology: 0 <--> 1 <--> 2 <--> 3
        self.topo = Topology.create_line_topology(num_qpus=4, latency=10.0, fidelity=0.98, bell_pairs=20)
        self.router = ShortestPathRouter()

    def test_direct_route(self):
        path = self.router.route(self.topo, 0, 1)
        self.assertEqual(path, [0, 1])

    def test_multi_hop_route(self):
        path = self.router.route(self.topo, 0, 3)
        self.assertEqual(path, [0, 1, 2, 3])

    def test_same_source_destination(self):
        path = self.router.route(self.topo, 2, 2)
        self.assertEqual(path, [2])

    def test_path_cost_all_edges(self):
        path = [0, 1, 2, 3]
        cost = self.router.calculate_path_cost(self.topo, path)
        # 3 edges, each edge cost > 0
        self.assertGreater(cost, 30.0)

    def test_congestion_aware_routing(self):
        # Create triangle: 0 <--> 1 (congested), 0 <--> 2 <--> 1 (uncongested)
        topo = Topology()
        topo.add_qpu(0, 4)
        topo.add_qpu(1, 4)
        topo.add_qpu(2, 4)

        # High congestion direct link
        topo.connect(0, 1, latency=10.0, congestion=90.0)
        # Low congestion alternative via 2
        topo.connect(0, 2, latency=5.0, congestion=0.0)
        topo.connect(2, 1, latency=5.0, congestion=0.0)

        router = ShortestPathRouter(alpha=1.0, beta=2.0)
        path = router.route(topo, 0, 1)
        # Should prefer multi-hop path [0, 2, 1] due to lower composite cost
        self.assertEqual(path, [0, 2, 1])

    def test_disconnected_network_error(self):
        topo = Topology()
        topo.add_qpu(0, 4)
        topo.add_qpu(1, 4)
        # No links added
        with self.assertRaises(nx.NetworkXNoPath):
            self.router.route(topo, 0, 1)


if __name__ == "__main__":
    unittest.main()

