"""
State-dependent behavior tests for the generic adaptive DQC simulation engine
(compiler/simulation.py). These exercise the decision pipeline directly against
hand-built network/partition states -- never the full randomized 50-step run --
so each scenario is deterministic and traceable to a specific letter in the
required test matrix (A-L).
"""
import os
import shutil
import unittest
from qiskit import QuantumCircuit

from network.topology import Topology
from network.monitor import NetworkMonitor
from compiler.compiler import DQCCompiler
from compiler.communication_graph import CommunicationGraph
from compiler.communication_cost import CommunicationCost
from compiler.optimizer import Optimizer
from compiler.repartition_trigger import RepartitionTrigger
from compiler.simulation import AdaptiveSimulator


class TestAdaptiveSimulation(unittest.TestCase):

    def setUp(self):
        self.image_dir = "test_adaptive_sim_output"
        os.makedirs(self.image_dir, exist_ok=True)

    def tearDown(self):
        if os.path.exists(self.image_dir):
            shutil.rmtree(self.image_dir)

    def _make_simulator(self, topo, qc, comm_graph, partition, compiled,
                         trigger=None, threshold=5.0, capacities=None):
        monitor = NetworkMonitor(topology=topo)
        sim = AdaptiveSimulator(
            compiler=DQCCompiler(),
            topology=topo,
            circuit=qc,
            comm_graph=comm_graph,
            monitor=monitor,
            trigger=trigger or RepartitionTrigger(latency_limit=20.0),
            optimizer=Optimizer(monitor=monitor),
            cost_calc=CommunicationCost(monitor=monitor),
            capacities=capacities or {qid: qpu.capacity for qid, qpu in topo.qpus.items()},
            graph_builder=CommunicationGraph(output_dir=self.image_dir),
            image_dir=self.image_dir,
            improvement_threshold=threshold
        )
        # Bypass establish_baseline() (which always re-derives the partition from
        # the partitioner) so the test can pin a specific, known starting state.
        sim.current_partition = partition
        sim.current_compiled = compiled
        sim.baseline_cost = sim._current_cost()
        sim.baseline_remote_operations = len(compiled.remote_operations)
        sim.baseline_max_congestion, _, _ = sim._link_metrics()
        return sim

    # --- A: Healthy network -> no trigger ------------------------------------
    def test_A_healthy_network_no_trigger(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=10.0, bell_pairs=50)
        trigger = RepartitionTrigger(latency_limit=20.0, fidelity_limit=0.95, congestion_limit=60.0, bellpair_limit=15)
        triggered, reason = trigger.check(topo)
        self.assertFalse(triggered)
        self.assertIn("healthy", reason.lower())

    # --- B: Congested network -> trigger (from actual routed demand) --------
    def test_B_congested_network_triggers(self):
        # Capacity 2 on link (0, 1); route 3 cross-QPU gates over it -> demand 3 > capacity 2.
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=3, capacity=2.0, bell_pairs=50)
        qc = QuantumCircuit(6)
        qc.cx(0, 3)
        qc.cx(1, 4)
        qc.cx(2, 5)
        partitions = {0: [0, 1, 2], 1: [3, 4, 5]}
        compiled = DQCCompiler().recompile_for_partition(qc, partitions, topo)

        self.assertGreater(topo.get_link(0, 1).congestion, 100.0)

        trigger = RepartitionTrigger(congestion_limit=20.0)
        triggered, reason = trigger.check(topo)
        self.assertTrue(triggered)
        self.assertIn("congestion", reason.lower())

    # --- C / L: Trigger fires but no beneficial candidate -> no change, no image
    def test_C_and_L_trigger_without_beneficial_candidate_produces_no_image(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=10.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)
        comm_graph = CommunicationGraph(output_dir=self.image_dir).build(qc)
        # Already-optimal partition for this interaction pattern.
        partition = {0: [0, 1], 1: [2, 3]}
        compiled = DQCCompiler().recompile_for_partition(qc, partition, topo)

        sim = self._make_simulator(topo, qc, comm_graph, partition, compiled)
        topo.update_link(0, 1, latency=35.0)  # exceeds default 20.0 limit -> triggers

        result = sim.evaluate_and_maybe_repartition(step_idx=1)

        self.assertTrue(result.triggered)
        self.assertTrue(result.optimizer_run)
        self.assertFalse(result.partition_changed)
        self.assertFalse(result.accepted)
        self.assertEqual(sim.trigger_events_without_partition_change, 1)
        self.assertEqual(sim.actual_repartitions, 0)

        images = [f for f in os.listdir(self.image_dir) if f.startswith("actual_repartition")]
        self.assertEqual(len(images), 0)

    # --- D / K: Trigger + beneficial candidate -> exactly one actual repartition + one image
    def test_D_and_K_beneficial_candidate_causes_one_repartition_and_one_image(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=5.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        for _ in range(5):
            qc.cx(0, 2)
            qc.cx(1, 3)
        comm_graph = CommunicationGraph(output_dir=self.image_dir).build(qc)
        # Poor initial partition: interacting pairs (0,2) and (1,3) split across QPUs.
        partition = {0: [0, 1], 1: [2, 3]}
        compiled = DQCCompiler().recompile_for_partition(qc, partition, topo)

        sim = self._make_simulator(topo, qc, comm_graph, partition, compiled, threshold=5.0)
        topo.update_link(0, 1, latency=25.0)  # triggers via latency

        result = sim.evaluate_and_maybe_repartition(step_idx=7)

        self.assertTrue(result.triggered)
        self.assertTrue(result.partition_changed)
        self.assertTrue(result.accepted)
        self.assertGreater(result.logical_qubits_moved, 0)
        self.assertEqual(sim.actual_repartitions, 1)
        self.assertEqual(len(sim.repartition_events), 1)
        self.assertEqual(sim.repartition_events[0].step, 7)

        images = [f for f in os.listdir(self.image_dir) if f == "actual_repartition_01_step_07.png"]
        self.assertEqual(len(images), 1)

    # --- E: Demand-derived congestion (never random) -------------------------
    def test_E_demand_derived_congestion(self):
        topo = Topology.create_line_topology(num_qpus=3, qpu_capacity=3, capacity=2.0, bell_pairs=50)
        qc = QuantumCircuit(6)
        qc.cx(0, 4)  # path [0, 1, 2]
        qc.cx(1, 5)  # path [0, 1, 2]
        qc.cx(0, 2)  # path [0, 1]
        partitions = {0: [0, 1], 1: [2, 3], 2: [4, 5]}
        DQCCompiler().recompile_for_partition(qc, partitions, topo)

        link_01 = topo.get_link(0, 1)
        link_12 = topo.get_link(1, 2)
        # demand=3, capacity=2 -> utilization=1.5 -> congestion=150% (uncapped, from routed demand only)
        self.assertEqual(link_01.demand, 3.0)
        self.assertEqual(link_01.congestion, 150.0)
        self.assertEqual(link_12.demand, 2.0)
        self.assertEqual(link_12.congestion, 100.0)

    # --- F: Multi-hop route demand --------------------------------------------
    def test_F_multihop_route_increments_demand_on_every_traversed_edge(self):
        topo = Topology.create_line_topology(num_qpus=4, qpu_capacity=1, capacity=10.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        qc.cx(0, 3)  # must traverse [0, 1, 2, 3]
        partitions = {0: [0], 1: [1], 2: [2], 3: [3]}
        compiled = DQCCompiler().recompile_for_partition(qc, partitions, topo)

        path = list(compiled.routes.values())[0]
        self.assertEqual(path, [0, 1, 2, 3])
        for u, v in [(0, 1), (1, 2), (2, 3)]:
            self.assertEqual(topo.get_link(u, v).demand, 1.0)

    # --- G: Capacity change changes congestion (existing demand held fixed) --
    def test_G_capacity_change_recalculates_congestion(self):
        topo = Topology()
        topo.add_qpu(0, 4)
        topo.add_qpu(1, 4)
        topo.connect(0, 1, capacity=5.0)
        topo.update_link(0, 1, demand=5.0)
        self.assertEqual(topo.get_link(0, 1).congestion, 100.0)

        topo.update_link(0, 1, capacity=10.0)
        # Same demand, doubled capacity -> congestion halves, recomputed automatically.
        self.assertEqual(topo.get_link(0, 1).demand, 5.0)
        self.assertEqual(topo.get_link(0, 1).congestion, 50.0)

    # --- H: Bell-pair accounting ----------------------------------------------
    def test_H_bell_pair_accounting(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, bell_pairs=50, capacity=10.0)
        initial, consumed, remaining = topo.get_total_bell_pairs()
        self.assertEqual(initial, 50)
        self.assertEqual(consumed, 0)
        self.assertEqual(remaining, 50)

        qc = QuantumCircuit(4)
        qc.cx(0, 2)
        qc.cx(1, 3)
        DQCCompiler().recompile_for_partition(qc, {0: [0, 1], 1: [2, 3]}, topo)

        initial2, consumed2, remaining2 = topo.get_total_bell_pairs()
        self.assertEqual(initial2, 50)
        self.assertGreater(consumed2, 0)
        self.assertEqual(remaining2, initial2 - consumed2)
        self.assertGreaterEqual(remaining2, 0)

    # --- I: Current cost changes when network state changes (never stale) ----
    def test_I_current_cost_reflects_current_network_state(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, latency=15.0, capacity=10.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        qc.cx(0, 2)
        comm_graph = CommunicationGraph(output_dir=self.image_dir).build(qc)
        partition = {0: [0, 1], 1: [2, 3]}

        cost_calc = CommunicationCost()
        cost_before = cost_calc.calculate(comm_graph, partition, topology=topo)

        topo.update_link(0, 1, latency=15.0 + 500.0)
        cost_after = cost_calc.calculate(comm_graph, partition, topology=topo)

        self.assertGreater(cost_after, cost_before)

    # --- J: Partition change regenerates routes/resources --------------------
    def test_J_partition_change_regenerates_routes_and_demand(self):
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=5.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        for _ in range(5):
            qc.cx(0, 2)
            qc.cx(1, 3)
        comm_graph = CommunicationGraph(output_dir=self.image_dir).build(qc)
        partition = {0: [0, 1], 1: [2, 3]}
        compiled = DQCCompiler().recompile_for_partition(qc, partition, topo)

        self.assertGreater(topo.get_link(0, 1).demand, 0.0)

        sim = self._make_simulator(topo, qc, comm_graph, partition, compiled, threshold=5.0)
        topo.update_link(0, 1, latency=25.0)
        result = sim.evaluate_and_maybe_repartition(step_idx=1)

        self.assertTrue(result.partition_changed)
        self.assertGreater(result.routes_changed, 0)
        # After moving to the collocated partition [0, 2] / [1, 3], no remote ops remain
        # and demand on the old congested link must be recalculated back to zero.
        self.assertEqual(len(sim.current_compiled.remote_operations), 0)
        self.assertEqual(topo.get_link(0, 1).demand, 0.0)
        self.assertEqual(topo.get_link(0, 1).congestion, 0.0)

    # --- M: Do not rerun an unchanged optimization problem -------------------
    def test_M_repeated_trigger_against_unchanged_state_skips_optimizer(self):
        """
        Same setup as C/L (trigger fires, no beneficial candidate). Calling the
        decision pipeline again with nothing having changed must NOT rerun the
        optimizer a second time -- but a genuine change to the live state
        (here, network evolution) must re-arm it.
        """
        topo = Topology.create_line_topology(num_qpus=2, qpu_capacity=2, capacity=10.0, bell_pairs=50)
        qc = QuantumCircuit(4)
        qc.h(0)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)
        comm_graph = CommunicationGraph(output_dir=self.image_dir).build(qc)
        partition = {0: [0, 1], 1: [2, 3]}
        compiled = DQCCompiler().recompile_for_partition(qc, partition, topo)

        sim = self._make_simulator(topo, qc, comm_graph, partition, compiled)
        topo.update_link(0, 1, latency=35.0)

        result_1 = sim.evaluate_and_maybe_repartition(step_idx=1)
        self.assertTrue(result_1.triggered)
        self.assertTrue(result_1.optimizer_run)
        self.assertEqual(sim.optimizer_runs, 1)

        # Nothing about the live state changed -- same trigger, same fingerprint.
        result_2 = sim.evaluate_and_maybe_repartition(step_idx=2)
        self.assertTrue(result_2.triggered)
        self.assertFalse(result_2.optimizer_run)
        self.assertEqual(sim.optimizer_runs, 1)
        self.assertEqual(sim.repartition_triggers, 2)
        self.assertEqual(sim.trigger_events_without_partition_change, 2)

        # A genuine change to the live network re-arms the search.
        topo.update_link(0, 1, latency=40.0)
        result_3 = sim.evaluate_and_maybe_repartition(step_idx=3)
        self.assertTrue(result_3.triggered)
        self.assertTrue(result_3.optimizer_run)
        self.assertEqual(sim.optimizer_runs, 2)


if __name__ == "__main__":
    unittest.main()
