import os
from typing import Optional, Dict, List, Union
import matplotlib.pyplot as plt
import networkx as nx


class Visualizer:
    """
    Renders and exports communication graphs and partition layouts to the 'graph/' directory.
    """

    def __init__(self, output_dir: str = "graph"):
        self.output_dir = output_dir

    def draw(
        self,
        graph: nx.Graph,
        filename: str = "communication_graph.png",
        title: str = "Communication Graph",
        partitions: Optional[Union[Dict[int, List[int]], Dict[int, int]]] = None,
        subtitle: Optional[str] = None,
        output_dir: Optional[str] = None
    ) -> str:
        """
        Draw graph with optional partition coloring and save into the graph/ directory.
        """
        target_dir = output_dir or self.output_dir
        os.makedirs(target_dir, exist_ok=True)

        if not filename.endswith(".png"):
            filename = f"{filename}.png"

        filepath = os.path.join(target_dir, filename)

        fig, ax = plt.subplots(figsize=(10, 8))

        try:
            pos = nx.kamada_kawai_layout(graph)
        except Exception:
            pos = nx.spring_layout(graph, seed=42)

        node_colors = []
        palette = [
            "#4C78A8", "#F58518", "#54A24B", "#E45756",
            "#72B7B2", "#EECA3B", "#B279A2", "#FF9DA6"
        ]

        if partitions is not None:
            qpu_map = {}
            for k, v in partitions.items():
                if isinstance(v, (list, tuple, set)):
                    for q in v:
                        qpu_map[q] = k
                else:
                    qpu_map[k] = v

            for node in graph.nodes():
                qpu_id = qpu_map.get(node, 0)
                node_colors.append(palette[qpu_id % len(palette)])
        else:
            node_colors = ["#4C78A8" for _ in graph.nodes()]

        nx.draw_networkx_nodes(
            graph,
            pos,
            ax=ax,
            node_color=node_colors,
            node_size=1200,
            edgecolors="#111111",
            linewidths=1.8
        )
        nx.draw_networkx_labels(
            graph,
            pos,
            ax=ax,
            font_size=12,
            font_weight="bold",
            font_color="white"
        )

        edges = list(graph.edges(data=True))
        if edges:
            weights = [d.get("weight", 1) for _, _, d in edges]
            max_w = max(weights) if weights else 1
            widths = [1.5 + 3.0 * (w / max_w) for w in weights]

            nx.draw_networkx_edges(
                graph,
                pos,
                ax=ax,
                width=widths,
                alpha=0.75,
                edge_color="#333333"
            )

            edge_labels = {(u, v): f"w={d.get('weight', 1)}" for u, v, d in edges}
            nx.draw_networkx_edge_labels(
                graph,
                pos,
                ax=ax,
                edge_labels=edge_labels,
                font_size=9,
                font_color="#222222"
            )

        if partitions is not None:
            legend_elements = []
            present_qpus = sorted(list(set(qpu_map.values())))
            for q_id in present_qpus:
                c = palette[q_id % len(palette)]
                qubits_on_qpu = [q for q, p in qpu_map.items() if p == q_id]
                patch = plt.Line2D(
                    [0], [0],
                    marker='o', color='w',
                    label=f"QPU {q_id} (Qubits: {qubits_on_qpu})",
                    markerfacecolor=c, markersize=10, markeredgecolor='black'
                )
                legend_elements.append(patch)
            ax.legend(handles=legend_elements, loc='upper right', framealpha=0.9, fontsize=9)

        full_title = title
        if subtitle:
            full_title += f"\n{subtitle}"

        ax.set_title(full_title, fontsize=13, fontweight="bold", pad=15)
        ax.axis("off")
        plt.tight_layout()
        plt.savefig(filepath, dpi=300, bbox_inches="tight")
        plt.close(fig)

        print(f"Graph visualization saved to: {filepath}")
        return filepath